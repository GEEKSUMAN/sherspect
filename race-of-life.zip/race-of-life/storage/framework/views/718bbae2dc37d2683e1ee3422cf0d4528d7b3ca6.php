<!-- core:js -->
<script src="<?php echo e(asset('/vendors/core/core.js')); ?>"></script>
<!-- endinject -->
<!-- plugin js for this page -->
<script src="<?php echo e(asset('/vendors/chartjs/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/jquery.flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/jquery.flot/jquery.flot.resize.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
<!-- end plugin js for this page -->
<!-- inject:js -->
<script src="<?php echo e(asset('/vendors/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/template.js')); ?>"></script>
<!-- endinject -->
<!-- custom js for this page -->
<script src="<?php echo e(asset('/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('/js/datepicker.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- end custom js for this page -->
<!-- Datatable -->
<script type="text/javascript" charset="utf8"
src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

<script>
    // $("#logout").click(function (e) {
    //     e.preventDefault();
    //     $.ajaxSetup({
    //         headers: {
    //             'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
    //         }
    //     });
    //     var logout={"logout":true}
    //     $.ajax({
    //         type: "POST",
    //         url: "logout",
    //         data: logout,
    //         dataType: "json",
    //         success: function (response) {
    //             window.location.reload();
    //         }
    //     });


    // });
</script>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/footer.blade.php ENDPATH**/ ?>