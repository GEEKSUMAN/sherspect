<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Skins</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Skin</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="skinLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="skinLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th class="pt-0">Shield Strength</th>
                                        <th class="pt-0">Max Shield Strength</th>
                                        <th class="pt-0">Price</th>
                                        <th class="pt-0">Skin texture color 1</th>
                                        <th class="pt-0">Skin texture color 2</th>
                                        <th class="pt-0">Skin texture color 3</th>
                                        <th class="pt-0">Skin texture color 4</th>
                                        <th class="pt-0">Skin texture color 5</th>
                                        <th class="pt-0">Skin texture color 6</th>
                                        <th class="pt-0">Skin texture color 7</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="skinLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->name); ?></td>
                                            <td> <?php echo e($item->image); ?></td>
                                            <td> <?php echo e($item->shield_strength); ?></td>
                                            <td> <?php echo e($item->max_shield_strength); ?></td>
                                            <td> <?php echo e($item->gcu_value); ?></td>
                                            <td class="texture1" data-id="<?php echo e($item->skin_texture_color_id_1); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_1): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture2" data-id="<?php echo e($item->skin_texture_color_id_2); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_2): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture3" data-id="<?php echo e($item->skin_texture_color_id_3); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_3): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture4" data-id="<?php echo e($item->skin_texture_color_id_4); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_4): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture5" data-id="<?php echo e($item->skin_texture_color_id_5); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_5): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture6" data-id="<?php echo e($item->skin_texture_color_id_6); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_6): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="texture7" data-id="<?php echo e($item->skin_texture_color_id_7); ?>">
                                                <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $texture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($texture->texture_id == $item->skin_texture_color_id_7): ?>
                                                        <?php echo e($texture->texture_color); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteSkin" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deleteSkin" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Skin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="skin_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="name" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Image</label>
                    <input id="image" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Price (JCU)</label>
                    <input id="gcu_value" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild</label>
                    <input id="shield_strength" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Max Sheild</label>
                    <input id="max_shield_strength" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 1</label>
                    <select class="required" id="texture_id_1"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;">
                        <option value="0" selected="selected">Select Texture 1</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?> - <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 2</label>
                    <select class="required" id="texture_id_2"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;">
                        <option value="0" selected="selected">Select Texture 2</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 3</label>
                    <select class="required" id="texture_id_3"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 3</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 4</label>
                    <select class="required" id="texture_id_4"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 4</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 5</label>
                    <select class="required" id="texture_id_5"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 5</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 6</label>
                    <select class="required" id="texture_id_6"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 6</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 7</label>
                    <select class="required" id="texture_id_7"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 7</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateSkin" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Skin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">

                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_name" type="text" class="required add_skin" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Image</label>
                    <input id="add_image" type="text" class="required add_skin" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Price (JCU)</label>
                    <input id="add_gcu_value" type="text" class="required add_skin" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild</label>
                    <input id="add_shield_strength" type="text" class="required add_skin" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Max Sheild</label>
                    <input id="add_max_shield_strength" type="text" class="required add_skin" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 1</label>
                    <select class="required" id="add_texture_id_1"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;">
                        <option value="0" selected="selected">Select Texture 1</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?> - <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 2</label>
                    <select class="required" id="add_texture_id_2"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;">
                        <option value="0" selected="selected">Select Texture 2</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 3</label>
                    <select class="required" id="add_texture_id_3"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 3</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 4</label>
                    <select class="required" id="add_texture_id_4"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 4</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 5</label>
                    <select class="required" id="add_texture_id_5"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 5</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 6</label>
                    <select class="required" id="add_texture_id_6"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 6</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Texture Color 7</label>
                    <select class="required" id="add_texture_id_7"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="0" selected="selected">Select Texture 7</option>
                        <?php $__currentLoopData = $textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->texture_id); ?>">
                                <?php echo e($key->texture_color); ?>- <?php echo e($key->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addSkin" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#skinLists").dataTable({ processing: true});
    });
</script>
<script>
    // Delete Skin
    $("button.deleteSkin").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var skin_id = $(this).val();
        var formData = {
            "skin_id": skin_id
        }
        //alert(skin_id);
        $.ajax({
            type: "POST",
            url: "deleteSkin",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.skinLists").click(function() {

        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();
        // console.log(tableData[6],tableData[7],tableData[8]);alert(tableData);
            $("#skin_id").val(tableData[0]);
            $("#name").val(tableData[1]);
            $("#image").val(tableData[2]);
            $('#shield_strength').val(tableData[3]);
            $("#max_shield_strength").val(tableData[4]),
            $('#gcu_value').val(tableData[5]);
            $('#texture_id_1').val($(this).children("td.texture1").attr('data-id'));
            $('#texture_id_2').val($(this).children("td.texture2").attr('data-id'));
            $('#texture_id_3 ').val($(this).children("td.texture3").attr('data-id'));
            $('#texture_id_4 ').val($(this).children("td.texture4").attr('data-id'));
            $('#texture_id_5 ').val($(this).children("td.texture5").attr('data-id'));
            $('#texture_id_6 ').val($(this).children("td.texture6").attr('data-id'));
            $('#texture_id_7 ').val($(this).children("td.texture7").attr('data-id'));
        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addSkin').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.add_skin").each(function() {
            //alert($(this).val());
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "name": $("#add_name").val(),
            "image": $("#add_image").val(),
            "shield_strength": $('#add_shield_strength').val(),
            "max_shield_strength":$('#add_max_shield_strength').val(),
            "gcu_value": $('#add_gcu_value').val(),
            "skin_texture_color_id_1": $('#add_texture_id_1 option:selected').val(),
            "skin_texture_color_id_2": $('#add_texture_id_2 option:selected').val(),
            "skin_texture_color_id_3": $('#add_texture_id_3 option:selected').val(),
            "skin_texture_color_id_4": $('#add_texture_id_4 option:selected').val(),
            "skin_texture_color_id_5": $('#add_texture_id_5 option:selected').val(),
            "skin_texture_color_id_6": $('#add_texture_id_6 option:selected').val(),
            "skin_texture_color_id_7": $('#add_texture_id_7 option:selected').val()
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addSkin",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    // console.log(data);
                    // alert();
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateSkin").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "skin_id": $("#skin_id").val(),
            "name": $("#name").val(),
            "image": $("#image").val(),
            "shield_strength": $('#shield_strength').val(),
            "max_shield_strength":$('#max_shield_strength').val(),
            "gcu_value": $('#gcu_value').val(),
            "skin_texture_color_id_1": $('#texture_id_1 option:selected').val(),
            "skin_texture_color_id_2": $('#texture_id_2 option:selected').val(),
            "skin_texture_color_id_3": $('#texture_id_3 option:selected').val(),
            "skin_texture_color_id_4": $('#texture_id_4 option:selected').val(),
            "skin_texture_color_id_5": $('#texture_id_5 option:selected').val(),
            "skin_texture_color_id_6": $('#texture_id_6 option:selected').val(),
            "skin_texture_color_id_7": $('#texture_id_7 option:selected').val()
        };
        $.ajax({
            type: "POST",
            url: "updateSkin",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    // alert();
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_skins.blade.php ENDPATH**/ ?>