<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of tournaments</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add tournaments</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="tournamentsesLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="tournamentsesLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th>Status</th>
                                        <th class="pt-0">Mothership</th>
                                        <th class="pt-0">Entry Fee(JCU)</th>
                                        <th class="pt-0">Duration(Mins)</th>
                                        <th class="pt-0">Start Date</th>
                                        <th class="pt-0">Start Time</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tournamentsesLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->tournament_name); ?></td>
                                            <td style=" width: 100px; height: 100px; padding: 0;">
                                                <img style="width: 100px;height: 100px;display: block; border-radius: 2px;"
                                                    src="<?php echo e(url('uploads/' . $item->image)); ?>"
                                                    alt="<?php echo e($item->image); ?>" />
                                                <button style="background:#41d1f6" class="verify_btn"
                                                    data-toggle="modal" data-target="#modalImg"><i data-feather="upload"
                                                        style="width: 30%;"></i>Change</button>
                                            </td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td> <?php echo e($item->mothership); ?></td>
                                            <td> <?php echo e($item->entry_fee); ?></td>
                                            <td> <?php echo e($item->duration); ?></td>
                                            <td> <?php echo e($item->start_date); ?></td>
                                            <td> <?php echo e($item->start_time); ?></td>

                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deletetournaments" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deletetournaments" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit tournaments</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="tournaments_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="tournaments_name" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Status</label>
                    <select class="required" id="status"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="status">
                        <option value="">Select Status</option>
                        <option value="1">
                            Active
                        </option>
                        <option value="0">
                            Inactive
                        </option>

                    </select>
                    <label style="font-weight: 600; width:35% ;  float:left;">Mothership</label>
                    
                    <select class="required" id="mothership"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="mothership">
                        <option value="">Select mothership</option>
                        <option value="1">
                            Buri
                        </option>
                        <option value="2">
                            Surt
                        </option>
                        <option value="3">
                            Herm
                        </option>
                        <option value="4">
                            Gerd
                        </option>

                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Entry Fee(JCU)</label>
                    <input id="entry_fee" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Match Duration(Minuites)</label>
                    <input id="duration" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Select Date & Time</label>
                    <div class="input-group date datepicker dashboard-date mr-2 mb-2 mb-md-0 d-md-none d-xl-flex" id="">
                        <span class="input-group-addon bg-transparent"><i data-feather="calendar"
                                class=" text-primary"></i></span>
                        <input id="datepick" type="text" class="form-control">
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updatetournaments" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add tournaments</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_tournaments_name" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>

                    <div>
                        <label style="font-weight: 600; width:35% ;  float:left;">Status</label>
                        <select class="addtournaments" id="add_status"
                            style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;">
                            <option value="" selected>Select Status</option>
                            <option value="1">
                                Active
                            </option>
                            <option value="0">
                                Inactive
                            </option>

                        </select>
                    </div>
                    <label style="font-weight: 600; width:35% ;  float:left;">Mothership</label>
                    
                    <select class="addtournaments" id="add_mothership"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="add_mothership">
                        <option value="">Select mothership</option>
                        <option value="1">
                            Buri
                        </option>
                        <option value="2">
                            Surt
                        </option>
                        <option value="3">
                            Herm
                        </option>
                        <option value="4">
                            Gerd
                        </option>

                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Entry Fee(JCU)</label>
                    <input id="add_entry_fee" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Match Duration(Minuites)</label>
                    <input id="add_duration" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Select Date & Time</label>
                    <div class="input-group  date datepicker dashboard-date mr-2 mb-2 mb-md-0 d-md-none d-xl-flex" id="">
                        <span class="input-group-addon bg-transparent"><i data-feather="calendar"
                                class=" text-primary"></i></span>
                        <input id="add_datepick" type="text" class="form-control required">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addtournaments" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal img -->
<div class="modal fade" id="modalImg" tabindex="-1" role="dialog" aria-labelledby="modalImgtitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalImgtitle">Change Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="file" accept="image/x-png,image/gif,image/jpeg" id="file">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="img_upload" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal img -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        $("#datepick").datetimepicker({
            format: 'Y-m-d H:i:s',
            step: 15,
            scrollTime: true,
        });
        $("#add_datepick").datetimepicker({
            format: 'Y-m-d H:i:s',
            step: 15,
            scrollTime: true,
        });

    });
    // alert($('#datepick').datetimepicker('getValue'));

    $(function() {
        var table = $("#tournamentsesLists").dataTable();
    });
    //     $('#add_rank_id').change(function() {
    //        alert();
    //      });
</script>
<script>
    // Delete tournaments
    $("button.deletetournaments").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var tournaments_id = $(this).val();
        var formData = {
            "tournament_id": tournaments_id
        }
        //alert(tournaments_id);
        $.ajax({
            type: "POST",
            url: "deletetournaments",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.tournamentsesLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();

        $("#tournaments_id").val(tableData[0]);
        $("#tournaments_name").val(tableData[1]);
        var status = jQuery.trim(tableData[3]);
        $("#status").val(status);
        $("#mothership").val(jQuery.trim(tableData[4]));
        $("#entry_fee").val(tableData[5]);
        $("#duration").val(tableData[6]);
        let datepick = tableData[7] + "" + tableData[8];
        console.log(datepick);
        $("#datepick").val(datepick);


        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addtournaments').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        //  check select fields
        $("select.addtournaments").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var datedpick=new Date($("#add_datepick").val());
        var formData = {
            "tournament_name": $("#add_tournaments_name").val(),
            "entry_fee": $("#add_entry_fee").val(),
            "status": $("#add_status option:selected").val(),
            "duration": $("#add_duration").val(),
            "mothership": $("#add_mothership option:selected").val(),
            "start_date":datedpick.toISOString().substring(0,10),
            "start_time":datedpick.toISOString().substring(11,19),
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addtournaments",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updatetournaments").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var datedpick=new Date($("#datepick").val());
        var formData = {
            "tournament_id": $("#tournaments_id").val(),
            "tournament_name": $("#tournaments_name").val(),
            "status": $("#status option:selected").val(),
            "entry_fee": $("#entry_fee").val(),
            "mothership": $("#mothership option:selected").val(),
            "start_date":datedpick.toISOString().substring(0,10),
            "start_time":datedpick.toISOString().substring(11,19),
            "duration": $("#duration").val(),
        };
        $.ajax({
            type: "POST",
            url: "updatetournaments",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>
<script>
    $(document).ready(function() {
        $("#img_upload").click(function() {
            var fd = new FormData();
            var files = $('#file')[0].files;
            // Check file selected or not
            if (files.length > 0) {
                fd.append('file', files[0]);
                fd.append('tournament_id', $("#tournaments_id").val());
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: 'uploadtournamentFile',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.res != 0) {
                            window.location.reload();
                        } else {
                            alert('file not uploaded');
                        }
                    },
                });
            } else {
                alert("Please select a file.");
            }
        });
    });
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_tournaments.blade.php ENDPATH**/ ?>