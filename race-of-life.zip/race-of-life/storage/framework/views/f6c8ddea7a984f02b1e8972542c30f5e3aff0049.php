<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of User's Wallets</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="UsersList" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Player Name</th>
                                        <th class="pt-0">Email</th>
                                        <th class="pt-0">Country</th>
                                        <th class="pt-0">Wallet Balance</th>
                                        <th class="pt-0">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="pending"> <?php echo e($item->user_id); ?></td>
                                            <td> <?php echo e($item->player_name); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->country_name); ?></td>
                                            <td> <?php echo e($item->jc_amount); ?></td>

                                            <td> <button id="enable-user-<?php echo e($item->user_id); ?>"
                                                    onclick="enableClick(<?php echo e($item->user_id); ?>)"
                                                    class="confirm_btn verify_btn"><i
                                                        data-feather="align-justify"></i>More</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Wallet Transactions</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="debit-tab" data-toggle="tab" href="#debit" role="tab"
                            aria-controls="debit" aria-selected="true">Debit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="credit-tab" data-toggle="tab" href="#credit" role="tab"
                            aria-controls="credit" aria-selected="false">Credit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="withdraw-tab" data-toggle="tab" href="#withdraw" role="tab"
                            aria-controls="withdraw" aria-selected="false">Withdraw</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="debit" role="tabpanel" aria-labelledby="debit-tab">
                        <table id="debitDtls" class="table table-hover mb-0">
                            <thead>
                                <th>Amount</th>
                                <th>description</th>
                                <th>Date</th>
                            </thead>
                            <tbody>
                                <tr></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="credit" role="tabpanel" aria-labelledby="credit-tab">
                        <table id="creditDtls" class="table table-hover mb-0">
                            <thead>
                                <th>Amount</th>
                                <th>description</th>
                                <th>Date</th>
                            </thead>
                            <tbody>
                                <tr></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="withdraw" role="tabpanel" aria-labelledby="withdraw-tab">
                        <table id="withdrawDtls" class="table table-hover mb-0">
                            <thead>
                                <th>Amount</th>
                                <th>description</th>
                                <th>Date</th>
                            </thead>
                        </table>
                        <tbody>
                            <tr></tr>
                        </tbody>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

            </div>
        </div>
    </div>
</div>
<!--  modal end-->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#UsersList").dataTable({
            "aaSorting": [
                [4, "desc"]
            ] // Sort by first column descending
        });
    });
</script>
<script type="text/javascript">
    $('#exampleModalLong').on('hidden.bs.modal', function() {

        $('#exampleModalLong tbody').empty();

    })
    /* enable user ajax*/
    function enableClick(id) {
        var user_id = id;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            user_id: user_id
        };

        $.ajax({
            type: "POST",
            url: "getUserWalletTransactions",
            data: formData,
            dataType: 'json',
            success: function(res) {
                res.forEach(appndElement);

                function appndElement(item) {
                    var type = item.type;

                    if (type == 'debit') {
                        //Getting value from to populate
                        var amount = item.jc_amount;
                        var description = item.description;
                        var date = item.date;
                        //Prepare TR to add in Table
                        var tr;
                        tr = $('<tr/>');
                        tr.append("<td>" + amount + "</td>");
                        tr.append("<td>" + description + "</td>");
                        tr.append("<td>" + date + "</td>");
                        $('#debitDtls').append(tr);

                    } else if (type == 'credit') {
                        //Getting value from to populate
                        var amount = item.jc_amount;
                        var description = item.description;
                        var date = item.date;
                        //Prepare TR to add in Table
                        var tr;
                        tr = $('<tr/>');
                        tr.append("<td>" + amount + "</td>");
                        tr.append("<td>" + description + "</td>");
                        tr.append("<td>" + date + "</td>");
                        $('#creditDtls').append(tr);
                    } else {
                        //Getting value from to populate
                        var amount = item.jc_amount;
                        var description = item.description;
                        var date = item.date;
                        //Prepare TR to add in Table
                        var tr;
                        tr = $('<tbody/>');
                        tr.append("<td>" + amount + "</td>");
                        tr.append("<td>" + description + "</td>");
                        tr.append("<td>" + date + "</td>");
                        $('#withdrawDtls').append(tr);
                    }
                }
                if (res.length === 0) {
                    $('#exampleModalLong').modal('hide');
                } else {
                    $('#exampleModalLong').modal('toggle');
                }

            },
            error: function(data) {
                console.log(data);
            }
        });
    }
    /* enable user ajax end*/
</script>
</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_users_wallets.blade.php ENDPATH**/ ?>