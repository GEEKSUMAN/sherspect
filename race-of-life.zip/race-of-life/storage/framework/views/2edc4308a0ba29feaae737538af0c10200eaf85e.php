<!doctype html>
<html>
   <head>
		<meta charset="utf-8">
		<title>Earth Knight</title>
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>" type="text/css">
		<link rel="icon" href="<?php echo e(asset('frontend/images/favicon.png')); ?>" type="image/png" sizes="24x24">

		<meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap 4 CDN link -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <!-- Bootstrap 4 Files -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

        <!-- font awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

        <!-- responsive navbar-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



        <!--both slider-->
		<script src="https://wlada.github.io/vue-carousel-3d/js/carousel-3d.umd.js"></script>
		<script src="https://wlada.github.io/vue-carousel-3d/js/vue.js"></script>


		<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2//2.0.0-beta.2.4/owl.carousel.min.js"></script>

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.carousel.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.theme.default.css">



        <!--____________________________________google font___________________________________________________________-->
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Philosopher:wght@400;700&display=swap" rel="stylesheet">

    </head>

    <body class="full_page_width_set">






		<div class="container-fluid px-0">
			<div class="row no-gutters">
				<div class="col-lg-12 topv_resp">
					<video src="<?php echo e(asset('frontend/images/top_banner.mp4')); ?>"  loop muted autoplay class="w-100 float-left">
					</video>
				</div>
			</div>

			<div class="row no-gutters baner_inner-text_top">
				<div class="col-lg-2 col-4">
        			<a href="a" class="logo_outer"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>"  class="logo img-fluid"/></a>
				</div>



				<div class="col-lg-10 col-8">
					<div class="social_buttons_top">
                        <a href="https://www.facebook.com/Knightcallmobile/"><img src="<?php echo e(asset('frontend/images/fb.png')); ?>"  class="img-fluid"/></a>
						<a href="https://www.instagram.com/knightcall2021/?utm_medium=copy_link"><img src="<?php echo e(asset('frontend/images/insta.png')); ?>"  class="img-fluid"/></a>
						<a href="https://twitter.com/knight_call"><img src="<?php echo e(asset('frontend/images/tweetr.png')); ?>"  class="img-fluid"/></a>
					</div>
				</div>

				<div class="col-lg-12 banner_text">
					<div class="play_intro">
						<span class="play_btn_banner">
							<a href="#"><img src="<?php echo e(asset('frontend/images/play_btn.png')); ?>"  class="img-fluid"/></a>
						</span>

						<span class="play_btn_bannerr">
							<a href="#"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>"  class="img-fluid" style="width: 16%;margin-bottom: 21px;"/></a>
						</span>

						<span class="download_icons_banner">
							<a href="#" class="button two">
								<img src="<?php echo e(asset('frontend/images/google_store.png')); ?>"  class="img-fluid"/>
							</a>
							<a href="#">
								<img src="<?php echo e(asset('frontend/images/app_store.png')); ?>"  class="img-fluid" />
							</a>
							<a href="#">
								<img src="<?php echo e(asset('frontend/images/amazon_store.png')); ?>"  class="img-fluid"/>
							</a>
							<a href="#">
								<img src="<?php echo e(asset('frontend/images/huwawe_store.png')); ?>"  class="img-fluid"/>
							</a>
							<a href="#">
								<img src="<?php echo e(asset('frontend/images/galaxy_store.png')); ?>"  class="img-fluid"/>
							</a>
						</span>
					</div>

				</div>
			</div>
		</div>

		<div class="container-fluid seprator_bnr">
			<div class="row">
				<div class="col-lg-12">
				</div>
			</div>
		</div>

		<div class="container-fluid ftr_slider">
			<div class="row">
				<div class="col-lg-12">
					<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/GAME-VIEW1.png')); ?>" /></h2>
				</div>

				<div class="col-lg-12" style="overflow: hidden;">
					<div id="example">
						<carousel-3d :autoplay="true" :autoplay-timeout="5000" :controls-visible="true" :controls-prev-html="'&#x2039; '" :controls-next-html="'&#x203A;'"  :controls-width="50" :controls-height="50" :clickable="true">


						  <slide  :index="0">
							  <img src="<?php echo e(asset('frontend/images/slider1.jpg')); ?>" >
						  </slide>

						  <slide :index="1">
							  <img src="<?php echo e(asset('frontend/images/slider2.jpg')); ?>" >
						  </slide>

						  <slide  :index="2">
							  <img src="<?php echo e(asset('frontend/images/slider3.jpg')); ?>" >
						  </slide>

						</carousel-3d>
					  </div>
				</div>
			</div>
		</div>

		<div class="container-fluid seprator_bnr">
			<div class="row">
				<div class="col-lg-12">
				</div>
			</div>
		</div>

		<div class="container-fluid ftr_slider2 pb-5">
			<div class="row">
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-2">
							<div class="tab tabs_all">
								<button class="tablinks" onclick="openCity(event, 'avatar')" id="defaultOpen"><img src="<?php echo e(asset('frontend/images/tabs_1.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'robot')"><img src="<?php echo e(asset('frontend/images/tabs_3.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'jet')"><img src="<?php echo e(asset('frontend/images/tabs_2.png')); ?>"  class="img-fluid"/></button>
							</div>
							<div class="tab tabs_all tabs_alll rsp_phn2">
								<button class="tablinks" onclick="openCity(event, 'monster')"><img src="<?php echo e(asset('frontend/images/tabs_4.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'mothership')"><img src="<?php echo e(asset('frontend/images/tabs_5.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'dron')"><img src="<?php echo e(asset('frontend/images/tabs_6.png')); ?>"  class="img-fluid"/></button>
							</div>
						</div>
						<div class="col-lg-8" style="margin-top: 10px;">
							<div class="row tabcontent" id="avatar" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/avatar.png')); ?>"  style="width: 20%;"/></h2>
								</div>
								<div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/ava_6.png')); ?>"  alt="">
													<p>Anders</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_5-1.png')); ?>"  alt="">
														<p>Brenna</p></div>

												<div><img src="<?php echo e(asset('frontend/images/ava_1.png')); ?>"  alt="">
													<p>RAGNAR</p></div>

												<div><img src="<?php echo e(asset('frontend/images/ava_3.png')); ?>"  alt="">
													<p>Yrsa</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_4.png')); ?>"  alt="">
													<p>Tove</p></div>


												<div><img src="<?php echo e(asset('frontend/images/ava_7.png')); ?>"  alt="">
													<p>VIDAR</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_8.png')); ?>"  alt="">
													<p>AMA</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_9.png')); ?>"  alt="">
													<p>ASTRA</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_10.png')); ?>"  alt="">
													<p>BJORN</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_11.png')); ?>"  alt="">
													<p>GUNNAR</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_12.png')); ?>"  alt="">
													<p>MAJNUS</p></div>
												<!-- <div><img src="<?php echo e(asset('frontend/images/ava_13.png')); ?>"  alt="">
													<p>REVNA</p></div> -->
												<div><img src="<?php echo e(asset('frontend/images/ava_14.png')); ?>"  alt="">
													<p>REVNA</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_15.png')); ?>"  alt="">
													<p>ERLENA</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ava_2.png')); ?>"  alt="">
													<p>TOR</p></div>
                                            </div>


										</div>

									</div>

								</div>
							</div>

							<div class="row tabcontent" id="jet" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/jet.png')); ?>"  style="width: 20%;"/></h2>
								</div>
								<div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/jet1.png')); ?>" /><p>ARNE</p></div>
												<div>
													<img src="<?php echo e(asset('frontend/images/jet2.png')); ?>" /><p>BIRGER</p>
												  </div>
												  <div >
													<img src="<?php echo e(asset('frontend/images/jet4.png')); ?>" /><p>HARALD</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet3.png')); ?>" /><p>HILDA</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet5.png')); ?>" /><p>GUNHILD</p>
												  </div>

												  <div>
													<img src="<?php echo e(asset('frontend/images/jet6.png')); ?>" /><p>THYRA</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet7.png')); ?>" /><p>ASTRID</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet8.png')); ?>" /><p>FRODE</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet9.png')); ?>" /><p>STEN</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet10.png')); ?>" /><p>ROAR</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet11.png')); ?>" /><p>TOKE</p>
												  </div>
												  <div>
													<img src="<?php echo e(asset('frontend/images/jet12.png')); ?>" /><p>FRIDA</p>
												  </div>
                                            </div>


										</div>

									</div>

								</div>
							</div>

							<div class="row tabcontent" id="robot" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/robot.png')); ?>"  style="width: 20%;"/></h2>
								</div>
								<div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/robot-1.png')); ?>" /><p>Sunny</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-2.png')); ?>" /><p>Frost</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-3.png')); ?>" /><p>Drago</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-4.png')); ?>" /><p>Franko</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-5.png')); ?>" /><p>Snowy</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-6.png')); ?>" /><p>Flash</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-7.png')); ?>" /><p>Blast</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-8.png')); ?>" /><p>Flexy</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-9.png')); ?>" /><p>Light</p></div>
												<div><img src="<?php echo e(asset('frontend/images/robot-10.png')); ?>" /><p>Tower</p></div>

                                            </div>


										</div>

									</div>

								</div>

							</div>

							<div class="row tabcontent" id="monster" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/monsters.png')); ?>"  style="width: 20%;"/></h2>
								</div>
                                <div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/monster-1.png')); ?>" /><p>Njal</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-2.png')); ?>" /><p>Gro</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-3.png')); ?>" /><p>Vaiveahtoish</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-4.png')); ?>" /><p>Brunhilda</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-5.png')); ?>" /><p>Lyngheid</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-6.png')); ?>" /><p>Gorm</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-7.png')); ?>" /><p>Forsten</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-8.png')); ?>" /><p>Trygve</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-9.png')); ?>" /><p>Ulfhild</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-10.png')); ?>" /><p>Aslaug</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-11.png')); ?>" /><p>Hallr</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-12.png')); ?>" /><p>Frigg</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-13.png')); ?>" /><p>Valdis</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-14.png')); ?>" /><p>Alfrothul</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-15.png')); ?>" /><p>Anselma</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-16.png')); ?>" /><p>Draupnir</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-17.png')); ?>" /><p>Forseti</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-18.png')); ?>" /><p>Hrimfaxi</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-19.png')); ?>" /><p>Thorbiartl</p></div>
												<div><img src="<?php echo e(asset('frontend/images/monster-20.png')); ?>" /><p>Valmiki</p></div>
                                            </div>


										</div>

									</div>

								</div>
							</div>

							<div class="row tabcontent" id="mothership" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/mothership.png')); ?>"  style="width: 20%;"/></h2>
								</div>
							    <div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/ms-1.png')); ?>" /><p>SURT</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ms-2.png')); ?>" /><p>HYRM</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ms-3.png')); ?>" /><p>GERD</p></div>
												<div><img src="<?php echo e(asset('frontend/images/ms-4.png')); ?>" /><p>BURI</p></div>
                                            </div>


										</div>

									</div>

								</div>
							</div>

							<div class="row tabcontent" id="dron" >
								<div class="col-lg-12">
									<h2 class="heading_all_column"><img src="<?php echo e(asset('frontend/images/drone.png')); ?>"  style="width: 20%;"/></h2>
								</div>
                                <div class="col-lg-12">
									<span class="btnpanel_scifii">
										<img src="<?php echo e(asset('frontend/images/panel_btm.png')); ?>"  class="img-fluid"/>
									</span>
									<div class="item_slider_ls">
										<div class="slider_3d_2">
											<div class="owl-carousel">
												<div><img src="<?php echo e(asset('frontend/images/drone1.png')); ?>" /><p>Oscar</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone2.png')); ?>" /><p>Ulf</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone3.png')); ?>" /><p>Saga</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone4.png')); ?>" /><p>Loki</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone5.png')); ?>" /><p>Ivar</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone6.png')); ?>" /><p>Ari</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone7.png')); ?>" /><p>Kari</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone8.png')); ?>" /><p>Randi</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone9.png')); ?>" /><p>Ake</p></div>
												<div><img src="<?php echo e(asset('frontend/images/drone10.png')); ?>" /><p>Dane</p></div>
                                            </div>

										</div>

									</div>

								</div>
							</div>
						</div>
						<div class="col-lg-2">
							<div class="tab tabs_all tabs_alll rsp_phn1">
								<button class="tablinks" onclick="openCity(event, 'monster')"><img src="<?php echo e(asset('frontend/images/tabs_4.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'mothership')"><img src="<?php echo e(asset('frontend/images/tabs_5.png')); ?>"  class="img-fluid"/></button>
								<button class="tablinks" onclick="openCity(event, 'dron')"><img src="<?php echo e(asset('frontend/images/tabs_6.png')); ?>"  class="img-fluid"/></button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="container-fluid px-0" style="position: absolute; z-index: -9;max-width: 1920px;">
			<div class="row no-gutters">
				<div class="col-lg-12">
					<img src="<?php echo e(asset('frontend/images/btm_banner.gif')); ?>"  loop muted autoplay class="w-100 float-left">
					</video>
				</div>
			</div>
		</div>

		<div class="container-fluid btm_banner">
				<div class="row">
					<div class="col-lg-12">
						<div class="play_intro">
							<span>
								<div class="social_buttons_top2">
									<a href="https://www.facebook.com/Knightcallmobile/"><img src="<?php echo e(asset('frontend/images/fb.png')); ?>"  class="img-fluid"/></a>
									<a href="https://www.instagram.com/knightcall2021/?utm_medium=copy_link"><img src="<?php echo e(asset('frontend/images/insta.png')); ?>"  class="img-fluid"/></a>
									<a href="https://twitter.com/knight_call"><img src="<?php echo e(asset('frontend/images/tweetr.png')); ?>"  class="img-fluid"/></a>
								</div>
							</span>
							<span class="download_icons_banner">
								<a href="#" class="button two">
									<img src="<?php echo e(asset('frontend/images/google_store.png')); ?>"  class="img-fluid"/>
								</a>
								<a href="#">
									<img src="<?php echo e(asset('frontend/images/app_store.png')); ?>"  class="img-fluid" />
								</a>
								<a href="#">
									<img src="<?php echo e(asset('frontend/images/amazon_store.png')); ?>"  class="img-fluid"/>
								</a>
								<a href="#">
									<img src="<?php echo e(asset('frontend/images/huwawe_store.png')); ?>"  class="img-fluid"/>
								</a>
								<a href="#">
									<img src="<?php echo e(asset('frontend/images/galaxy_store.png')); ?>"  class="img-fluid"/>
								</a>
							</span>
						</div>
					</div>
				</div>
		</div>

		<div class="container-fluid footer-btm-bar">
			<div class="row">
				<div class="col-md-12">
					<span class="footer_trii">
						<div class="footer_tri"></div>
					</span>
					<span>
						<a href="<?php echo e(url('/')); ?>" class="logo_outer"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>"  class="logo img-fluid"></a>
					</span>
                    <p>© 2021 Knight call All Rights Reserved.</p>
					<div class="btm_btns_r">
                        <a href="<?php echo e(url('terms_of_use')); ?>">Terms of Use</a> <a href="<?php echo e(url('contact_us')); ?>">Contact Us</a>
					</div>

				</div>
			</div>
		</div>

		<div class="container-fluid cokiee_tab_btm px-0" id="myDIV">
			<div class="row no-gutters cokiee_outer_tx">
				<div class="col-md-11 cokiiee_btm_txt">
                    <p>Our site uses cookies to analyze web traffic.</p><a href="cookie_policy.html">Learn more</a>
				</div>

				<div class="col-md-1 cokiiee_btm_txt_btn">
					<button onclick="myFunction()">GOT IT!</button>
				</div>
			</div>
		</div>





<!-------------------------------------------game view slider--------------------------------------------------->
<!-------------------------------------------game view slider--------------------------------------------------->
<script>
  new Vue({
	el: '#example',

	components: {
	  'carousel-3d': window['carousel-3d'].Carousel3d,
	  'slide': window['carousel-3d'].Slide
	}
  })
</script>



<script>
	$('.owl-carousel').owlCarousel({
		autoplay: false,
		center: true,
		loop: true,
		nav: true,
	});
</script>
<!-------------------------------------------game view slider--------------------------------------------------->
<!-------------------------------------------game view slider--------------------------------------------------->



<!-------------------------------------------tabs--------------------------------------------------->
<!-------------------------------------------tabs--------------------------------------------------->
<script>
	function openCity(evt, cityName) {
		console.log('evt');
		console.log(evt);
		console.log('cityName='+cityName);
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.className += " active";
	}

	// Get the element with id="defaultOpen" and click on it
	document.getElementById("defaultOpen").click();
</script>
<!-------------------------------------------tabs--------------------------------------------------->
<!-------------------------------------------tabs--------------------------------------------------->




<!-------------------------------------------cookie btm bar--------------------------------------------------->
<!-------------------------------------------cookie btm bar--------------------------------------------------->
<script>
	function myFunction() {
	  var x = document.getElementById("myDIV");
	  if (x.style.display === "none") {
		x.style.display = "block";
	  } else {
		x.style.display = "none";
	  }
	}
</script>
<!-------------------------------------------cookie btm bar--------------------------------------------------->
<!-------------------------------------------cookie btm bar--------------------------------------------------->

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\admin-knightcall\resources\views/welcome.blade.php ENDPATH**/ ?>