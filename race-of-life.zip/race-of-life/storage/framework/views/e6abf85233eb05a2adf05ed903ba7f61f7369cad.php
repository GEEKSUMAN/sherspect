<!-- core:js -->
<script src="<?php echo e(asset('/vendors/core/core.js')); ?>"></script>
<!-- endinject -->
<!-- plugin js for this page -->
<script src="<?php echo e(asset('/vendors/chartjs/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/jquery.flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/jquery.flot/jquery.flot.resize.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
<!-- end plugin js for this page -->
<!-- inject:js -->
<script src="<?php echo e(asset('/vendors/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/template.js')); ?>"></script>
<!-- endinject -->
<!-- custom js for this page -->
<script src="<?php echo e(asset('/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('/js/datepicker.js')); ?>"></script>
<!-- end custom js for this page -->
<!-- Datatable -->
<script type="text/javascript" charset="utf8"
src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

<script>
    // $("#logout").click(function (e) {
    //     e.preventDefault();
    //     $.ajaxSetup({
    //         headers: {
    //             'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
    //         }
    //     });
    //     var logout={"logout":true}
    //     $.ajax({
    //         type: "POST",
    //         url: "logout",
    //         data: logout,
    //         dataType: "json",
    //         success: function (response) {
    //             window.location.reload();
    //         }
    //     });


    // });
</script>
<?php /**PATH C:\xampp\htdocs\admin-knightcall\resources\views/footer.blade.php ENDPATH**/ ?>