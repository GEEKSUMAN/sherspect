<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">Welcome to Dashboard</h4>

        </div>
        <h4 class="mb-3 mb-md-0 pull-right">Total Earnings <span id="total_earning" class="text-primary"><?php echo e($total); ?></span></h4>
    </div>
    <div class="row">
        <div class="col-12 col-xl-12 stretch-card">
            <div class="row flex-grow">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-baseline">
                                <h6 class="card-title mb-0">Choose Date </h6>
                                <caption>Choose the From Date and To Date for Daily, Monthly & Weekly earning reports</caption>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-9">
                                    <label class="mr-4">From Date</label><input value="<?php echo e($from_date); ?>" placeholder="Choose From Date" type="text" id="from_date">
                                    <label class="ml-5 mr-4">To Date</label>
                                    <input value="<?php echo e($to_date); ?>"
                                        placeholder="Choose To Date" type="text" id="to_date">
                                    <button id="date_submit" class="btn btn-primary ml-2">Submit</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline pt-2 pb-1">
                        <h6 class="card-title mb-0">List Earnings</h6>

                    </div>
                    <div class="d-flex flex-column">

                        <div class="table-responsive">

                            <br><br>
                            <table id="earningsTable" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Amount</th>
                                        <th class="pt-0">Description</th>
                                        <th class="pt-0">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->player_name); ?></td>
                                        <td><?php echo e($item->jc_amount); ?></td>
                                        <td><?php echo e($item->description); ?></td>
                                        <td><?php echo e($item->date); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div> <!-- row -->

</div>


</div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>

<script>
    $(function() {
        $("#from_date").datetimepicker({
            format: 'Y-m-d',
            timepicker: false,
        });
        $("#to_date").datetimepicker({
            format: 'Y-m-d',
            timepicker: false,
        });

    });

    $("#date_submit").click(function (e) {
        e.preventDefault();
        var from_date= $("#from_date").val();
        var to_date= $("#to_date").val();
        location.href='<?php echo e(url("dashboard")); ?>/'+from_date+'/'+to_date;
        //console.log(from_date,to_date);

    });

    $(document).ready(function() {
        var total= "Total Earnings = "+$("#total_earning").text();
       
        $('#earningsTable').DataTable({
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'spacer',
                    style: 'bar',
                    text: 'Export files'
                },
                {
                    extend: 'excelHtml5',
                    messageTop: total,
                    className: 'btn btn-primary',
                },
                {
                    extend: 'pdfHtml5',
                    className: 'btn btn-primary',
                    messageTop: total,
                },
            ]
        });
    });
</script>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/dashboard.blade.php ENDPATH**/ ?>