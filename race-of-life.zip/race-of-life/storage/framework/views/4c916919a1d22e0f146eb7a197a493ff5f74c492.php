<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Battalions</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="List" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Battalion Name</th>
                                        <th class="pt-0">Description</th>
                                        <th class="pt-0">Leader</th>
                                        <th class="pt-0">Co Leader</th>
                                        <th class="pt-0">Country</th>
                                        <th class="pt-0">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->battalion_name); ?></td>
                                            <td><?php echo e($item->description); ?></td>
                                            <td><?php echo e($item->user_id); ?></td>
                                            <td> <?php echo e($item->co_leader_id); ?></td>
                                            <td> <?php echo e($item->country); ?></td>

                                            <td><a href="<?php echo e(url('showMembers/')); ?>/<?php echo e($item->id); ?>" id=""  class="verify_btn"> <i
                                                        data-feather="user"></i>See Members</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#List").dataTable();
    });
</script>
</body>
</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_battalions.blade.php ENDPATH**/ ?>