<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Weapons</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Weapon</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">
                            <br><br>
                            <table id="WeaponsLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="weaponsLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Damage(Min)</th>
                                        <th class="pt-0">Damage(Max)</th>
                                        <th class="pt-0">Stab Damage</th>
                                        <th class="pt-0">Throw Damage</th>
                                        <th class="pt-0">Magazine Capacity(Min)</th>
                                        <th class="pt-0">Magazine Capacity(Max)</th>
                                        <th class="pt-0">Bullet Mode</th>
                                        <th class="pt-0">Damage Range Linear</th>
                                        <th class="pt-0">Damage Range Radius</th>
                                        <th class="pt-0">Description</th>
                                        <th class="pt-0">JCU</th>
                                        <th class="pt-0">AP</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="weaponsLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->name); ?></td>
                                            <td> <?php echo e($item->damage_mininum_per_bullet); ?></td>
                                            <td> <?php echo e($item->damage_maximum_per_bullet); ?></td>
                                            <td> <?php echo e($item->stab_damage); ?></td>
                                            <td> <?php echo e($item->throw_damage); ?></td>
                                            <td> <?php echo e($item->magazine_capacity_minimum); ?></td>
                                            <td> <?php echo e($item->magazine_capacity_maximum); ?></td>
                                            <td> <?php echo e($item->bullet_mode); ?></td>
                                            <td> <?php echo e($item->damage_range_linear); ?></td>
                                            <td> <?php echo e($item->damage_range_radius); ?></td>
                                            <td> <?php echo e($item->description); ?></td>
                                            <td> <?php echo e($item->gcu_value); ?></td>
                                            <td> <?php echo e($item->ap_value); ?></td>
                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteWeapon" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deleteWeapon" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Weapon</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="weapon_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="name" type="text" class="border" Value="Class 5" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage(Min)</label>
                    <input id="damage_mininum_per_bullet" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage(Max)</label>
                    <input id="damage_maximum_per_bullet" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Stab Damage</label>
                    <input id="stab_damage" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Throw Damage</label>
                    <input id="throw_damage" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Magazine Capacity(Min)</label>
                    <input id="magazine_capacity_minimum" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Magazine Capacity(Max)</label>
                    <input id="magazine_capacity_maximum" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Bullet Mode</label>
                    <input id="bullet_mode" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage Range Linear</label>
                    <input id="damage_range_linear" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage Range Radius</label>
                    <input id="damage_range_radius" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Description</label>
                    <input id="description" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">JCU</label>
                    <input id="gcu_value" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">AP</label>
                    <input id="ap_value" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateWeapon" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Weapon</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_name" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage(Min)</label>
                    <input id="add_damage_mininum_per_bullet" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage(Max)</label>
                    <input id="add_damage_maximum_per_bullet" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Stab Damage</label>
                    <input id="add_stab_damage" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Throw Damage</label>
                    <input id="add_throw_damage" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Magazine Capacity(Min)</label>
                    <input id="add_magazine_capacity_minimum" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Magazine Capacity(Max)</label>
                    <input id="add_magazine_capacity_maximum" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Bullet Mode</label>
                    <input id="add_bullet_mode" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage Range Linear</label>
                    <input id="add_damage_range_linear" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Damage Range Radius</label>
                    <input id="add_damage_range_radius" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Description</label>
                    <input id="add_description" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">JCU</label>
                    <input id="add_gcu_value" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">AP</label>
                    <input id="add_ap_value" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <select class="required" id="add_status">
                        <option value="" selected="selected">Select If Paid/Free</option>
                        <option value="1">
                            Paid
                        </option>
                        <option value="0">
                            Free
                        </option>
                    </select>
                    <select class="required" id="add_melee">
                        <option value="" selected="selected">Select If Melee Weapon</option>
                        <option value="1">
                            Yes
                        </option>
                        <option value="0">
                            No
                        </option>
                    </select>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addWeapon" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {
        $("#WeaponsLists").dataTable();
    });
</script>
<script>
    // Delete Weapon
    $("button.deleteWeapon").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var weapon_id = $(this).val();
        var formData = {
            "weapon_id": weapon_id
        }
        //alert(weapon_id);
        $.ajax({
            type: "POST",
            url: "deleteWeapon",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.weaponsLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();
        $("#weapon_id").val(tableData[0]);
        $("#name").val(tableData[1]);
        $("#damage_mininum_per_bullet").val(tableData[2]);
        $("#damage_maximum_per_bullet").val(tableData[3]);
        $("#stab_damage").val(tableData[4]);
        $("#throw_damage").val(tableData[5]);
        $("#magazine_capacity_minimum").val(tableData[6]);
        $("#magazine_capacity_maximum").val(tableData[7]);
        $("#bullet_mode").val(tableData[8]);
        $("#damage_range_linear").val(tableData[9]);
        $("#damage_range_radius").val(tableData[10]);
        $("#description").val(tableData[11]);
        $("#gcu_value").val(tableData[12]);
        $("#ap_value").val(tableData[13]);
        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addWeapon').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        //  check select fields
        $("select.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "name": $("#add_name").val(),
           "damage_mininum_per_bullet": $("#add_damage_mininum_per_bullet").val(),
           "damage_maximum_per_bullet" :$("#add_damage_maximum_per_bullet").val(),
           "stab_damage" :$("#add_stab_damage").val(),
           "throw_damage" :$("#add_throw_damage").val(),
            "magazine_capacity_minimum":$("#add_magazine_capacity_minimum").val(),
            "magazine_capacity_maximum":$("#add_magazine_capacity_maximum").val(),
            "bullet_mode":$("#add_bullet_mode").val(),
            "damage_range_linear":$("#add_damage_range_linear").val(),
            "damage_range_radius":$("#add_damage_range_radius").val(),
            "description":$("#add_description").val(),
            "gcu_value":$("#add_gcu_value").val(),
            "ap_value":$("#add_ap_value").val(),
            "is_melee":$("#add_melee").val(),
            "status":$("#add_status").val(),
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addWeapon",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateWeapon").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "weapon_id": $("#weapon_id").val(),
            "name": $("#name").val(),
           "damage_mininum_per_bullet": $("#damage_mininum_per_bullet").val(),
           "damage_maximum_per_bullet" :$("#damage_maximum_per_bullet").val(),
           "stab_damage" :$("#stab_damage").val(),
           "throw_damage" :$("#throw_damage").val(),
            "magazine_capacity_minimum":$("#magazine_capacity_minimum").val(),
            "magazine_capacity_maximum":$("#magazine_capacity_maximum").val(),
            "bullet_mode":$("#bullet_mode").val(),
            "damage_range_linear":$("#damage_range_linear").val(),
            "damage_range_radius":$("#damage_range_radius").val(),
            "description":$("#description").val(),
            "gcu_value":$("#gcu_value").val(),
            "ap_value":$("#ap_value").val(),
        };

        $.ajax({
            type: "POST",
            url: "updateWeapon",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_weapons.blade.php ENDPATH**/ ?>