<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of All Levels</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="DefendList" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Level</th>
                                        <th class="pt-0">Total sheild strength</th>
                                        <th class="pt-0">Enemy ship type</th>
                                        <th class="pt-0">Enemy ship number</th>
                                        <th class="pt-0">Enemy bullet number</th>
                                        <th class="pt-0">Enemy total bullets number(180 sec)</th>
                                        <th class="pt-0">Enemy sheild</th>
                                        <th class="pt-0">Bullet strength(20%)</th>
                                        <th class="pt-0">Hits to destroy enemy</th>
                                        <th class="pt-0">Enemy particle strengths</th>
                                        <th class="pt-0">Drone 1 particle strength</th>
                                        <th class="pt-0">Drone 2 particle strength</th>
                                        <th class="pt-0">Monster</th>
                                        <th class="pt-0">Number of enemy(50%)</th>
                                        <th class="pt-0">Number of enemy(75%)</th>
                                        <th class="pt-0">Number of enemy(100%)</th>
                                        <th class="pt-0">Monster bullet</th>
                                        <th class="pt-0">Monster shield</th>
                                        <th class="pt-0">Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="defendList">
                                            <td class="pending"> <?php echo e($item['id']); ?></td>
                                            <td> <?php echo e($item['level']); ?></td>
                                            <td> <?php echo e($item['player_total_sheild_strength']); ?></td>
                                            <td> <?php echo e($item['enemy_ship_type']); ?></td>
                                            <td> <?php echo e($item['enemy_ship_number']); ?></td>
                                            <td> <?php echo e($item['enemy_bullet_number_per_4_6sec']); ?></td>
                                            <td> <?php echo e($item['enemy_total_bullets_number_withing_180sec']); ?></td>
                                            <td> <?php echo e($item['enemy_sheild']); ?></td>
                                            <td> <?php echo e($item['player_bullet_stremgth_20_percent']); ?></td>
                                            <td> <?php echo e($item['hits_to_destroy_enemy']); ?></td>
                                            <td> <?php echo e($item['enemy_particle_strengths']); ?></td>
                                            <td> <?php echo e($item['drone_1_particle_strength']); ?></td>
                                            <td> <?php echo e($item['drone_2_particle_strength']); ?></td>
                                            <td> <?php echo e($item['monster']); ?></td>
                                            <td> <?php echo e($item['number_of_enemy_50_percent']); ?></td>
                                            <td> <?php echo e($item['number_of_enemy_75_percent']); ?></td>
                                            <td> <?php echo e($item['number_of_enemy_100_percent']); ?></td>
                                            <td> <?php echo e($item['monster_bullet']); ?></td>
                                            <td> <?php echo e($item['monster_shield']); ?></td>
                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width:40%;"></i>Edit </button></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>

<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Level</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="level_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Level</label>
                    <input id="level" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Total sheild strength</label>
                    <input id="player_total_sheild_strength" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy ship type</label>
                    <input id="enemy_ship_type" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy ship number</label>
                    <input id="enemy_ship_number" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy bullet number</label>
                    <input id="enemy_bullet_number_per_4_6sec" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy total bullets number(180
                        sec)</label>
                    <input id="enemy_total_bullets_number_withing_180sec" type="text" class="border"
                        Value="$300" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy sheild</label>
                    <input id="enemy_sheild" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Bullet strength(20%)</label>
                    <input id="player_bullet_stremgth_20_percent" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Hits to destroy enemy</label>
                    <input id="hits_to_destroy_enemy" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Enemy particle strengths</label>
                    <input id="enemy_particle_strengths" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Drone 1 particle strength</label>
                    <input id="drone_1_particle_strength" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Drone 2 particle strength</label>
                    <input id="drone_2_particle_strength" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Monster</label>
                    <input id="monster" type="text" class="border" Value="$300" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Number of enemy(50%)</label>
                    <input id="number_of_enemy_50_percent" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Number of enemy(75%)</label>
                    <input id="number_of_enemy_75_percent" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Number of enemy(100%)</label>
                    <input id="number_of_enemy_100_percent" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Monster bullet</label>
                    <input id="monster_bullet" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Monster shield</label>
                    <input id="monster_shield" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>


                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateLevel" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#DefendList").dataTable();
        $(".dataTables_filter").css("display", "none");
    });
</script>
<script>
    $("tr.defendList").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();
        $("#level_id").val(tableData[1]);
        $("#level").val(tableData[1]);
        $("#player_total_sheild_strength").val(tableData[2]);
        $("#enemy_ship_type").val(tableData[3]);
        $("#enemy_ship_number").val(tableData[4]);
        $("#enemy_bullet_number_per_4_6sec").val(tableData[5]);
        $("#enemy_total_bullets_number_withing_180sec").val(tableData[6]);
        $("#enemy_sheild").val(tableData[7]);
        $("#player_bullet_stremgth_20_percent").val(tableData[8]);
        $("#hits_to_destroy_enemy").val(tableData[9]);
        $("#enemy_particle_strengths").val(tableData[10]);
        $("#drone_1_particle_strength").val(tableData[11]);
        $("#drone_2_particle_strength").val(tableData[12]);
        $("#monster").val(tableData[13]);
        $("#number_of_enemy_50_percent").val(tableData[14]);
        $("#number_of_enemy_75_percent").val(tableData[15]);
        $("#number_of_enemy_100_percent").val(tableData[16]);
        $("#monster_bullet").val(tableData[17]);
        $("#monster_shield").val(tableData[18]);
        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $("#updateLevel").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "level": $("#level").val(),
            "player_total_sheild_strength": $("#player_total_sheild_strength").val(),
            "enemy_ship_type": $("#enemy_ship_type").val(),
            "enemy_ship_number": $("#enemy_ship_number").val(),
            "enemy_bullet_number_per_4_6sec": $("#enemy_bullet_number_per_4_6sec").val(),
            "enemy_total_bullets_number_withing_180sec": $("#enemy_total_bullets_number_withing_180sec").val(),
            "enemy_sheild": $("#enemy_sheild").val(),
            "player_bullet_stremgth_20_percent": $("#player_bullet_stremgth_20_percent").val(),
            "hits_to_destroy_enemy": $("#hits_to_destroy_enemy").val(),
            "enemy_particle_strengths": $("#enemy_particle_strengths").val(),
            "drone_1_particle_strength": $("#drone_1_particle_strength").val(),
            "drone_2_particle_strength": $("#drone_2_particle_strength").val(),
            "monster": $("#monster").val(),
            "number_of_enemy_50_percent": $("#number_of_enemy_50_percent").val(),
            "number_of_enemy_75_percent": $("#number_of_enemy_75_percent").val(),
            "number_of_enemy_100_percent": $("#number_of_enemy_100_percent").val(),
            "monster_bullet": $("#monster_bullet").val(),
            "monster_shield": $("#monster_shield").val(),
        };

        $.ajax({
            type: "POST",
            url: "updateDefendLevel",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>
</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_defend_levels.blade.php ENDPATH**/ ?>