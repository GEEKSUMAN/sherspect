<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
      <div>
        <h4 class="mb-3 mb-md-0">Welcome to Dashboard</h4>
      </div>
    </div>
    <div class="row">
      <div class="col-12 col-xl-12 stretch-card">
        <div class="row flex-grow">
          <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline">
                  <h6 class="card-title mb-0">Subscription Report </h6>
                  <div class="dropdown mb-2">
                    <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-6 col-md-12 col-xl-5">
                    <h3 class="mb-2">3,897</h3>
                    <div class="d-flex align-items-baseline">
                      <p class="text-success">
                        <span>+3.3%</span>
                        <i data-feather="arrow-up" class="icon-sm mb-1"></i>
                      </p>
                    </div>
                  </div>
                  <div class="col-6 col-md-12 col-xl-7">
                    <div id="apexChart1" class="mt-md-3 mt-xl-0"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline">
                  <h6 class="card-title mb-0">Total Earning</h6>
                  <div class="dropdown mb-2">
                    <button class="btn p-0" type="button" id="dropdownMenuButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton1">
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-7 col-md-12 col-xl-6">
                    <h3 class="mb-2">$ 35,084</h3>
                    <div class="d-flex align-items-baseline">
                      <p class="text-danger">
                        <span>-2.8%</span>
                        <i data-feather="arrow-down" class="icon-sm mb-1"></i>
                      </p>
                    </div>
                  </div>
                  <div class="col-6 col-md-12 col-xl-6">
                    <div id="apexChart2" class="mt-md-3 mt-xl-0"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline">
                  <h6 class="card-title mb-0">Registration Report</h6>
                  <div class="dropdown mb-2">
                    <button class="btn p-0" type="button" id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton2">
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                      <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-6 col-md-12 col-xl-5">
                    <h3 class="mb-2">89.87%</h3>
                    <div class="d-flex align-items-baseline">
                      <p class="text-success">
                        <span>+2.8%</span>
                        <i data-feather="arrow-up" class="icon-sm mb-1"></i>
                      </p>
                    </div>
                  </div>
                  <div class="col-6 col-md-12 col-xl-7">
                    <div id="apexChart3" class="mt-md-3 mt-xl-0"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline pt-2 pb-1">
              <h6 class="card-title mb-0">List of Users Registered</h6>
              <h6 class="card-title mb-0"><a href="show_list.html" style="background: #307bbd0a;border: 1px solid #0006;padding: 8px 12px;border-radius: 4px;font-size: 13px;font-weight: 600;color: #464646;"><i data-feather="eye" style="padding-right: 7px; margin-top: -1px;"></i>View All</a></h6>
            </div>
            <div class="d-flex flex-column">

              <div class="table-responsive">

                <br><br><table class="table table-hover mb-0">
                  <thead>
                    <tr>

                      <th class="pt-0"></th>
                      <th class="pt-0">Name</th>
                      <th class="pt-0">Email</th>
                      <th class="pt-0">Mobile</th>
                      <th class="pt-0">Level</th>
                      <th class="pt-0">Subscription Plan</th>
                      <th class="pt-0">Subscription Time</th>
                      <th class="pt-0">Action</th>
                    </tr>
                  </thead>
                  <tbody>

                    <tr>

                      <td>
                        <img src="assets/images/faces/face2.jpg" class="rounded-circle wd-35" alt="user">
                      </td>
                      <td>Leonardo Payne</td>
                      <td>leonardo_payme@</td>
                      <td>00000-00000</td>
                      <td class="pending">Level 2</td>
                      <td>$ 30</td>
                      <td>12:50 AM, 13/10/2020</td>
                      <td><button class="confirm_btn"> <i data-feather="user-x"></i> Block</button>
                          <button class="confirm_btn verify_btn"><i data-feather="user-check"></i>Unblock</button>
                      </td>
                    </tr>

                    <tr>

                      <td>
                        <img src="assets/images/faces/face3.jpg" class="rounded-circle wd-35" alt="user">
                      </td>
                      <td>Leonardo Payne</td>
                      <td>leonardo_payme@</td>
                      <td>00000-00000</td>
                      <td class="pending">Level 1</td>
                      <td>$ 30</td>
                      <td>12:50 AM, 13/10/2020</td>
                      <td><button class="confirm_btn"> <i data-feather="user-x"></i> Block</button>
                          <button class="confirm_btn verify_btn"><i data-feather="user-check"></i>Unblock</button>
                      </td>
                    </tr>

                    <tr>

                      <td>
                        <img src="assets/images/faces/face4.jpg" class="rounded-circle wd-35" alt="user">
                      </td>
                      <td>Leonardo Payne</td>
                      <td>leonardo_payme@</td>
                      <td>00000-00000</td>
                      <td class="pending">Level 5</td>
                      <td>$ 30</td>
                      <td>12:50 AM, 13/10/2020</td>
                      <td><button class="confirm_btn"> <i data-feather="user-x"></i> Block</button>
                          <button class="confirm_btn verify_btn"><i data-feather="user-check"></i>Unblock</button>
                      </td>
                    </tr>

                    <tr>

                      <td>
                        <img src="assets/images/faces/face5.jpg" class="rounded-circle wd-35" alt="user">
                      </td>
                      <td>Leonardo Payne</td>
                      <td>leonardo_payme@</td>
                      <td>00000-00000</td>
                      <td class="pending">Level 3</td>
                      <td>$ 30</td>
                      <td>12:50 AM, 13/10/2020</td>
                      <td><button class="confirm_btn"> <i data-feather="user-x"></i> Block</button>
                          <button class="confirm_btn verify_btn"><i data-feather="user-check"></i>Unblock</button>
                      </td>
                    </tr>

                    <tr>

                      <td>
                        <img src="assets/images/faces/face6.jpg" class="rounded-circle wd-35" alt="user">
                      </td>
                      <td>Leonardo Payne</td>
                      <td>leonardo_payme@</td>
                      <td>00000-00000</td>
                      <td class="pending">Level 4</td>
                      <td>$ 30</td>
                      <td>12:50 AM, 13/10/2020</td>
                      <td><button class="confirm_btn"> <i data-feather="user-x"></i> Block</button>
                          <button class="confirm_btn verify_btn"><i data-feather="user-check"></i>Unblock</button>
                      </td>
                    </tr>


                  </tbody>
                </table>


            </div>

            <ul class="pagination mt-5">
              <li class="page-item"><a class="page-link" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-left"><polyline points="11 17 6 12 11 7"></polyline><polyline points="18 17 13 12 18 7"></polyline></svg> </a></li>
              <li class="page-item"><a class="page-link active_pagination" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item"><a class="page-link" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-right"><polyline points="13 17 18 12 13 7"></polyline><polyline points="6 17 11 12 6 7"></polyline></svg></a></li>
            </ul>


            </div>
          </div>
        </div>
      </div>
    </div> <!-- row -->

        </div>


    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\admin-knightcall\resources\views/dashboard.blade.php ENDPATH**/ ?>