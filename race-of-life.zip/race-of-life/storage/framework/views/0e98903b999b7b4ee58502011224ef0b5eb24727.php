<!DOCTYPE html>
<html lang="en">


<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Knight Club</title>
	<!-- core:css -->
	<link rel="stylesheet" href="<?php echo e(asset('/vendors/core/core.css')); ?>">
	<!-- endinject -->
	<!-- plugin css for this page -->
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="<?php echo e(asset('/fonts/feather-font/css/iconfont.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
	<!-- endinject -->
	<!-- Layout styles -->
	<link rel="stylesheet" href="<?php echo e(asset('/css/demo_1/style.css')); ?>">
	<!-- End layout styles -->
	<link rel="shortcut icon" href="<?php echo e(asset('/images/favicon.png')); ?>" />
</head>

<body class="sidebar-dark">
    
	<div class="main-wrapper">
		<div class="page-wrapper full-page">
			<div class="page-content d-flex align-items-center justify-content-center">

				<div class="row w-100 mx-0 auth-page">
					<div class="col-md-8 col-xl-4 mx-auto">
						<div class="card" style="background: #000;">
							<div class="row">

								<div class="col-md-12 pl-md-0">
									<div class="auth-form-wrapper px-5 py-5">
										<a href="#" class="noble-ui-logo d-block mb-2" style="text-align: center;">
											<img src="<?php echo e(asset('/images/logo.png')); ?>" class="img-fluid" style="width: 50%;" />
										</a>
										<h5 class="text-muted font-weight-normal mb-4" style="text-align: center;">
											Welcome back! Log in to your account.</h5>
										<form action="<?php echo e(url('/login')); ?>" method="POST"  class="forms-sample">
                                            <?php echo csrf_field(); ?>
											<div class="form-group">
												<label for="exampleInputEmail1">Email address</label>
												<input type="email" name="email_id" class="form-control" id="exampleInputEmail1"
													placeholder="Email">
											</div>
											<div class="form-group">
												<label for="exampleInputPassword1">Password</label>
												<input type="password" name="password" class="form-control" id="exampleInputPassword1"
													autocomplete="current-password" placeholder="Password">
											</div>
											<div class="form-check form-check-flat form-check-primary">
												
											</div>

											<div class="mt-3" style="text-align: center;">
												<input type="submit" name="submit" value="Login"
													class="btn btn-primary mr-2 mb-2 mb-md-0 text-white"
													style="width: 35%;padding: 10px 0;background: #852323;border-radius: 8px;color: #fff !important;border: 2px solid #852323;box-shadow: 1px 2px 6px #00000045;">
											</div>

										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- core:js -->
	<script src="<?php echo e(asset('/vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
	<!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('/vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/template.js')); ?>"></script>
	<!-- endinject -->
	<!-- custom js for this page -->
	<!-- end custom js for this page -->
</body>


</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/login.blade.php ENDPATH**/ ?>