<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Monsters</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Monster</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">
                            <br><br>
                            <table id="MonstersLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="MonstersLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th class="pt-0">Monster Sheild</th>
                                        <th class="pt-0">Monster Bullet Strength</th>
                                        <th class="pt-0">Extra Sheild to Player</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="MonstersLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->name); ?></td>
                                            <td style=" width: 100px; height: 100px; padding: 0;">
                                                <img style="width: 100px;height: 100px;display: block; border-radius: 2px;"
                                                    src="<?php echo e(url('uploads/' . $item->image)); ?>"
                                                    alt="<?php echo e($item->image); ?>" />
                                                <button style="background:#41d1f6" class="verify_btn"
                                                    data-toggle="modal" data-target="#modalImg"><i data-feather="upload"
                                                        style="width: 30%;"></i>Change</button>
                                            </td>
                                            <td> <?php echo e($item->monster_sheild); ?></td>
                                            <td> <?php echo e($item->monster_bullet_strength); ?></td>
                                            <td> <?php echo e($item->extra_sheild_to_player); ?></td>

                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteWatch" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deleteWatch" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Watch</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="monster_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="monster_name" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Monster Sheild</label>
                    <input id="monster_sheild" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Monster Bullet Strength</label>
                    <input id="monster_bullet_strength" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Extra Sheild to Player</label>
                    <input id="extra_sheild_to_player" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateMonster" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Watch</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_monster_name" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>

                    <div>
                        <label style="font-weight: 600; width:35% ;  float:left;">Monster Sheild</label>
                        <input id="add_monster_sheild" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    </div>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Monster Bullet Strength</label>
                    <input id="add_monster_bullet_strength" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Extra Sheild to Player</label>
                    <input id="add_extra_sheild_to_player" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addMonster" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal img -->
<div class="modal fade" id="modalImg" tabindex="-1" role="dialog" aria-labelledby="modalImgtitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalImgtitle">Change Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="file" accept="image/x-png,image/gif,image/jpeg" id="file">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="img_upload" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal img -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#MonstersLists").dataTable();
    });
    //     $('#add_rank_id').change(function() {
    //        alert();
    //      });
</script>
<script>
    // Delete Watch
    $("button.deleteWatch").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var monster_id = $(this).val();
        var formData = {
            "monster_id": monster_id
        }
        //alert(monster_id);
        $.ajax({
            type: "POST",
            url: "deleteWatch",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.MonstersLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();

        $("#monster_id").val(tableData[0]);
        $("#monster_name").val(tableData[1]);
        var monster_sheild=  jQuery.trim(tableData[3]);
        $("#monster_sheild").val(monster_sheild);
        $("#monster_bullet_strength").val(tableData[4]);
        $("#extra_sheild_to_player").val(tableData[5]);

        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addMonster').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        //  check select fields
        $("select.monster_sheild").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "monster_name": $("#add_monster_name").val(),

            "monster_bullet_strength": $("#add_monster_bullet_strength").val(),
            "monster_sheild": $("#add_monster_sheild").val(),
            "extra_sheild_to_player": $("#add_extra_sheild_to_player").val()
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addMonster",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateMonster").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "monster_id": $("#monster_id").val(),
            "monster_name": $("#monster_name").val(),
            "monster_sheild": $("#monster_sheild").val(),
            "monster_bullet_strength": $("#monster_bullet_strength").val(),
            "extra_sheild_to_player": $("#extra_sheild_to_player").val()
        };
        $.ajax({
            type: "POST",
            url: "updateMonster",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>
<script>
    $(document).ready(function() {
        $("#img_upload").click(function() {
            var fd = new FormData();
            var files = $('#file')[0].files;
            // Check file selected or not
            if (files.length > 0) {
                fd.append('file', files[0]);
                fd.append('monster_id',$("#monster_id").val());
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: 'uploadMonsterFile',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.res != 0) {
                            window.location.reload();
                        } else {
                            alert('file not uploaded');
                        }
                    },
                });
            } else {
                alert("Please select a file.");
            }
        });
    });
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_monsters.blade.php ENDPATH**/ ?>