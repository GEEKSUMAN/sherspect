<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Loadouts</h4>
        </div>
        <button type="button" data-toggle="modal"
        data-target="#exampleModalCenterradd"  class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Loadout</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="loadoutsLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="loadoutsLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Watch</th>
                                        <th class="pt-0">Loadout</th>
                                        <th class="pt-0">Location</th>
                                        <th class="pt-0">Default Weapon</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="loadoutsLists">
                                            <td class="pending"> <?php echo e($item->loadout_id); ?></td>
                                            <td class="watchid" data-watchid="<?php echo e($item->watch_id); ?>"> <?php echo e($item->watch_name); ?></td>
                                            <td> <?php echo e($item->loadout_number); ?></td>
                                            <td> <?php echo e($item->loadout_location); ?></td>
                                            <td class="weaponid" data-weaponid="<?php echo e($item->weapon_id); ?>" > <?php echo e($item->weapon_name); ?></td>

                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteLoadout" value="<?php echo e($item->loadout_id); ?>" class="verify_btn deleteLoadout" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Loadout</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="Loadout_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Watch</label>
                    <select name="watch_id" id="watch_id">
                        <?php $__currentLoopData = $watches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($watch->id); ?>"><?php echo e($watch->watch_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Loadout</label>
                    <select name="loadout_number" id="loadout_number">
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Location</label>
                    <select name="loadout_location" id="loadout_location">
                        <option value="p_weapon1">p_weapon1</option>
                        <option value="p_weapon_sc1">p_weapon_sc1</option>
                        <option value="s_weapon1">s_weapon1</option>
                        <option value="s_weapon_sc1">s_weapon_sc1</option>
                        <option value="flame_X">Flame-X</option>
                        <option value="siege302">SIEGE-302</option>
                        <option value="grenade1">grenade1</option>
                        <option value="grenade2">grenade2</option>
                        <option value="grenade3">grenade3</option>
                        <option value="grenade4">grenade4</option>
                        <option value="tool1">Tool1</option>
                        <option value="tool2">Tool2</option>
                        <option value="tool3">Tool3</option>
                        <option value="tool4">Tool4</option>
                        <option value="tool5">Tool5</option>
                        <option value="tool6">Tool6</option>
                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Default Weapon</label>

                    <select name="weapon_id" id="weapon_id">
                        <option value="0">None</option>
                        <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($weapon->id); ?>"><?php echo e($weapon->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateLoadout" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Loadout</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Watch</label>
                    <select name="watch_id" id="add_watch_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $watches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($watch->id); ?>"><?php echo e($watch->watch_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Loadout</label>
                    <select name="loadout_number" id="add_loadout_number">
                        <option value="">Select</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Location</label>
                    <select name="loadout_location" id="add_loadout_location">
                        <option value="">Select</option>
                        <option value="p_weapon1">p_weapon1</option>
                        <option value="p_weapon_sc1">p_weapon_sc1</option>
                        <option value="s_weapon1">s_weapon1</option>
                        <option value="s_weapon_sc1">s_weapon_sc1</option>
                        <option value="flame_X">Flame-X</option>
                        <option value="siege302">SIEGE-302</option>
                        <option value="grenade1">grenade1</option>
                        <option value="grenade2">grenade2</option>
                        <option value="grenade3">grenade3</option>
                        <option value="grenade4">grenade4</option>
                        <option value="tool1">Tool1</option>
                        <option value="tool2">Tool2</option>
                        <option value="tool3">Tool3</option>
                        <option value="tool4">Tool4</option>
                        <option value="tool5">Tool5</option>
                        <option value="tool6">Tool6</option>
                    </select>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Default Weapon</label>

                    <select name="weapon_id" id="add_weapon_id">
                        <option value="0">None</option>
                        <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($weapon->id); ?>"><?php echo e($weapon->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addLoadout" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#loadoutsLists").dataTable();
    });
</script>
<script>
    // Delete Loadout
    $("button.deleteLoadout").click(function (e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var Loadout_id=$(this).val();
        var formData= {
            "loadout_id":Loadout_id
        }
        //alert(Loadout_id);
        $.ajax({
            type: "POST",
            url: "deleteLoadout",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.loadoutsLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();
        // console.log();
        // alert($(this).children("td.weaponid").data('weaponid'));
        $("#Loadout_id").val(tableData[0]);
        $("#watch_id").val($(this).children("td.watchid").attr('data-watchid'));
        $("#loadout_number").val(jQuery.trim(tableData[2]));
        $("#loadout_location").val(jQuery.trim(tableData[3]));
        $('#weapon_id').val($(this).children("td.weaponid").attr('data-weaponid'));
        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addLoadout').click(function (e) {
        e.preventDefault();
        var $val=0;

//check text fields
    $("input.required").each(function(){
        if (($(this).val())== ""){
              $(this).css('border-color', 'red');
              $val = 1
        }
        else{
            $(this).css('border-color', '');
        }

    });
  //  check select fields
    $("select").each(function(){
        if (($(this).val())== ""){
              $(this).css('border-color', 'red');
              $val = 1
        }
        else{
            $(this).css('border-color', '');
        }

    });
    if ($val > 0) {
        alert('Please enter the hightlighted values');
        return false;
    }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "watch_id":$("#add_watch_id option:selected").val(),
            "loadout_number":$("#add_loadout_number option:selected").val(),
            "loadout_location":$( "#add_loadout_location option:selected").val(),
            "weapon_id":$("#add_weapon_id option:selected").val(),
            "weapon_name":jQuery.trim($("#add_weapon_id option:selected").text())
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addLoadout",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateLoadout").click(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "loadout_id":$("#Loadout_id").val(),
            "watch_id":$("#watch_id option:selected").val(),
            "loadout_number":$("#loadout_number option:selected").val(),
            "loadout_location":$( "#loadout_location option:selected").val(),
            "weapon_id":$("#weapon_id option:selected").val(),
            "weapon_name":jQuery.trim($("#weapon_id option:selected").text())
        };

        $.ajax({
            type: "POST",
            url: "updateLoadout",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_loadouts.blade.php ENDPATH**/ ?>