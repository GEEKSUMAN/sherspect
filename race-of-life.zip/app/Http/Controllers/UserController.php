<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
   public function guestLogin(Request $request)
   {
      try {
         $validator = Validator::make($request->all(), [
            'device_token' => 'required',

         ]);


         if ($validator->fails()) {
            return response(['errors' => $validator->errors()->all()], 422);
         }

         $chk = DB::table('users')
            ->where(['device_token' => $request->device_token])
            ->first();
         if ($chk) {
            $user_id=$chk->id;
            $user = DB::table('users')
            ->where(['id' => $user_id])
            ->first();
         $level= DB::table('users_levels')
         ->where(['user_id' => $user_id])
         ->first();
         $score=DB::table('users_achivements')
         ->where(['user_id' => $user_id])
         ->first();
            $userData = [
               "uid" =>$user->id, 
               "achievement" => [
                     "uid" => $user->id, 
                     "totalScore" =>$score->score, 
                     "rank" => 1, 
                     "level" => [
                        "uid" => $user->id, 
                        "currentLevel" =>1, 
                        "totalXP" =>$level->xp, 
                        "xpToNextLevel" => 200
                     ] 
                  ], 
               "username" => $user->username ,
               "coin" => $user->game_coin
            ]; 
            return response()->json(['status' => true, 'message' => 'Login successfully', 'userData' => $userData], 200);
         } else {
            $user_id = DB::table('users')
               ->insertGetId([
                  'device_token' => $request->device_token,
                  'username' => 'guest' . rand(1, 99999),
               ]);
            $level=DB::table('users_levels')
            ->insertGetId([
               'user_id' => $user_id,
               'xp' =>0,
            ]);
            $achivements=DB::table('users_achivements')
            ->insertGetId([
               'user_id' => $user_id,
               'score' =>0,
            ]);
            $user = DB::table('users')
               ->where(['id' => $user_id])
               ->first();
            $level= DB::table('users_levels')
            ->where(['user_id' => $user_id])
            ->first();
            $score=DB::table('users_achivements')
            ->where(['user_id' => $user_id])
            ->first();
               $userData = [
                  "uid" =>$user->id, 
                  "achievement" => [
                        "uid" => $user->id, 
                        "totalScore" =>$score->score, 
                        "rank" => 1, 
                        "level" => [
                           "uid" => $user->id, 
                           "currentLevel" =>1, 
                           "totalXP" =>$level->xp, 
                           "xpToNextLevel" => 200
                        ] 
                     ], 
                  "username" => $user->username ,
                  "coin" => $user->game_coin
               ]; 
            return response()->json(['status' => true, 'message' => 'Login successfully', 'userData' => $userData], 200);
         }
      } catch (Exception $e) {
         return response()->json(['errors' => 'Bad Request'], 400);
      }
   }
   public function socialLogin(Request $request)
   {
      try {
         $validator = Validator::make($request->all(), [
            'device_token' => 'required',
            'social_user_id' => 'required'
         ]);

         if ($validator->fails()) {
            return response(['errors' => $validator->errors()->all()], 422);
         }

         $chk = DB::table('users')
            ->where(['social_user_id' => $request->social_user_id])
            ->first();
         if ($chk) {
            DB::table('users')
               ->where(['social_user_id' => $request->social_user_id])
               ->update([
                  'device_token' => $request->device_token
               ]);
               $user_id=$chk->id;
               $user = DB::table('users')
               ->where(['id' => $chk->id])
               ->first();
              
            $level= DB::table('users_levels')
            ->where(['user_id' => $user_id])
            ->first();
            $score=DB::table('users_achivements')
            ->where(['user_id' => $user_id])
            ->first();
               $userData = [
                  "uid" =>$user->id, 
                  "achievement" => [
                        "uid" => $user->id, 
                        "totalScore" =>$score->score, 
                        "rank" => 1, 
                        "level" => [
                           "uid" => $user->id, 
                           "currentLevel" =>1, 
                           "totalXP" =>$level->xp, 
                           "xpToNextLevel" => 200
                        ] 
                     ], 
                  "username" => $user->username ,
                  "coin" => $user->game_coin
               ]; 
            return response()->json([
               'status' => true,
               'message' => 'Login successfully',
               'userData' => $userData
            ], 200);
         } else {
            DB::table('users')
               ->where(['device_token' => $request->device_token])
               ->update([
                  'social_user_id' => $request->social_user_id
               ]);
              
               $user = DB::table('users')
               ->where(['device_token' => $request->device_token])
               ->first();
               $user_id=$user->id;
            $level= DB::table('users_levels')
            ->where(['user_id' => $user_id])
            ->first();
            $score=DB::table('users_achivements')
            ->where(['user_id' => $user_id])
            ->first();
               $userData = [
                  "uid" =>$user->id, 
                  "achievement" => [
                        "uid" => $user->id, 
                        "totalScore" =>$score->score, 
                        "rank" => 1, 
                        "level" => [
                           "uid" => $user->id, 
                           "currentLevel" =>1, 
                           "totalXP" =>$level->xp, 
                           "xpToNextLevel" => 200
                        ] 
                     ], 
                  "username" => $user->username ,
                  "coin" => $user->game_coin
               ]; 
            return response()->json([
               'status' => true,
               'message' => 'Social ID Linked successfully',
               'userData' => $userData
            ], 200);
         }
      } catch (Exception $e) {
         return response()->json(['errors' => 'Bad Request'], 400);
      }
   }


   public function emailLogin(Request $request)
   {
      try {
         $validator = Validator::make($request->all(), [
            'device_token' => 'required',
            'email' => 'required|email',
            'password' => 'required'
         ]);

         if ($validator->fails()) {
            return response(['errors' => $validator->errors()->all()], 422);
         }

         $chk = DB::table('users')
            //->where(['email' => $request->email, 'password'=>$request->password])
            ->where(['email' => $request->email])
            ->first();
         if ($chk) {
            if (Hash::check($request->password, $chk->password)) {
               DB::table('users')
               ->where(['id' =>$chk->id])
               ->update([
                  'device_token' => $request->device_token
               ]);
               $user_id=$chk->id;
               $user = DB::table('users')
               ->where(['id' => $user_id])
               ->first();
            $level= DB::table('users_levels')
            ->where(['user_id' => $user_id])
            ->first();
            $score=DB::table('users_achivements')
            ->where(['user_id' => $user_id])
            ->first();
               $userData = [
                  "uid" =>$user->id, 
                  "achievement" => [
                        "uid" => $user->id, 
                        "totalScore" =>$score->score, 
                        "rank" => 1, 
                        "level" => [
                           "uid" => $user->id, 
                           "currentLevel" =>1, 
                           "totalXP" =>$level->xp, 
                           "xpToNextLevel" => 200
                        ] 
                     ], 
                  "username" => $user->username ,
                  "coin" => $user->game_coin
               ]; 
            return response()->json([
               'status' => true,
               'message' => 'Login successfully',
               'userData' => $userData
            ], 200);
           }else{
            return response()->json([
               'status' => false,
               'message' => 'Password not matched',
               'userData' => []
            ], 200);
           }
            
         } else {
            DB::table('users')
               ->where(['device_token' => $request->device_token])
               ->update([
                  'email' => $request->email,
                  'password' => Hash::make($request->password)
               ]);
               $user = DB::table('users')
               ->where(['device_token' => $request->device_token])
               ->first();
               $user_id=$user->id;
            $level= DB::table('users_levels')
            ->where(['user_id' => $user_id])
            ->first();
            $score=DB::table('users_achivements')
            ->where(['user_id' => $user_id])
            ->first();
               $userData = [
                  "uid" =>$user->id, 
                  "achievement" => [
                        "uid" => $user->id, 
                        "totalScore" =>$score->score, 
                        "rank" => 1, 
                        "level" => [
                           "uid" => $user->id, 
                           "currentLevel" =>1, 
                           "totalXP" =>$level->xp, 
                           "xpToNextLevel" => 200
                        ] 
                     ], 
                  "username" => $user->username ,
                  "coin" =>  $user->game_coin ,
               ]; 
            return response()->json([
               'status' => true,
               'message' => 'Email Linked successfully',
               'userData' => $userData
            ], 200);
         }
      } catch (Exception $e) {
         return response()->json(['errors' => 'Bad Request'], 400);
      }
   }

   public function updateUserData(Request $request)
   {
      $validator = Validator::make($request->all(), [
         'user_id' => 'required',
         'username' => 'required',
         'avatarId' => 'required'
      ]);

      if ($validator->fails()) {
         return response(['errors' => $validator->errors()->all()], 422);
      }

      DB::table('users')
      ->where(['id' => $request->user_id])
      ->update([
         'username' => $request->username,
         'avatarId' => $request->avatarId
      ]);

      $userData = [
         "uid" =>$request->user_id, 
         "username" =>$request->username,
         "avatarId" =>  $request->avatarId ,
      ]; 
   return response()->json([
      'status' => true,
      'message' => 'User Name updated successfully',
      'userData' => $userData
   ], 200);

   }

}
