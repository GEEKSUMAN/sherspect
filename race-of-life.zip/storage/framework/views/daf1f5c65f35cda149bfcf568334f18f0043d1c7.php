<!doctype html>
<html>
   <head>
        <meta charset="utf-8">
        <title>Earth Knight</title>
        <link rel="stylesheet" href="frontend/css/style.css" type="text/css">
        <link rel="icon" href="images/favicon.png" type="image/png" sizes="24x24">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- Bootstrap 4 CDN link -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">  
        <!-- Bootstrap 4 Files -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>  
        
        <!-- font awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
        
        <!-- responsive navbar-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        


        <!--both slider-->
		<script src="https://wlada.github.io/vue-carousel-3d/js/carousel-3d.umd.js"></script>  
		<script src="https://wlada.github.io/vue-carousel-3d/js/vue.js"></script>  

		<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>  

		

        <!--____________________________________google font___________________________________________________________-->     
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Philosopher:wght@400;700&display=swap" rel="stylesheet"> 

    </head>

    <body class="full_page_width_set">






		<div class="container-fluid">
			<div class="row">
                <div class="col-md-12 terms_text  mt-4">
                    <p class="mb-0" style='font-size:64px;font-family:"inherit","serif";;width: 100%;float: left;text-align: center;'>Contact Us</span></u></strong></p>
                </div>

				<div class="col-lg-10 mx-auto pb-5">
                  
                        <div class="row">
                            <div class="col">
                                <div class="card">
                                    <div class="card-header bg-dark text-white"><i class="fa fa-envelope"></i> Contact us.
                                    </div>
                                    <div class="card-body">
                                        <form>
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Enter name" required="">
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Email address</label>
                                                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" required="">
                                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="message">Message</label>
                                                <textarea class="form-control" id="message" rows="3" required=""></textarea>
                                            </div>
                                            <div class="mx-auto">
                                            <button type="submit" class="btn btn-primary text-right">Submit</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <div class="card bg-light mb-3">
                                    <div class="card-header bg-dark text-white text-uppercase"><i class="fa fa-home"></i> Address</div>
                                    <div class="card-body">
                                        <p>June Games Co.
                                            king Abdullah II Eben Al Hussein Street,
                                           
                                           Camelia Center, second floor, Irbid 21110 Jordan   </p>
                                        <p>Attn: June Games Business and Legal Affairs</p>
                                       
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    
				</div>
			</div>
		</div>


   
        
        


<!-------------------------------------------game view slider--------------------------------------------------->  
<!-------------------------------------------game view slider--------------------------------------------------->   
<script>
  new Vue({
	el: '#example',
  
	components: {
	  'carousel-3d': window['carousel-3d'].Carousel3d,
	  'slide': window['carousel-3d'].Slide
	}
  })
</script>



<script>
var carousel = $(".carousell"),
    items = $(".item"),
    currdeg  = 0;

$(".nextt").on("click", { d: "n" }, rotate);
$(".prevv").on("click", { d: "p" }, rotate);

function rotate(e){
  if(e.data.d=="n"){
    currdeg = currdeg - 60;
  }
  if(e.data.d=="p"){
    currdeg = currdeg + 60;
  }
  carousel.css({
    "-webkit-transform": "rotateY("+currdeg+"deg)",
    "-moz-transform": "rotateY("+currdeg+"deg)",
    "-o-transform": "rotateY("+currdeg+"deg)",
    "transform": "rotateY("+currdeg+"deg)"
  });
    items.css({
    "-webkit-transform": "rotateY("+(-currdeg)+"deg)",
    "-moz-transform": "rotateY("+(-currdeg)+"deg)",
    "-o-transform": "rotateY("+(-currdeg)+"deg)",
    "transform": "rotateY("+(-currdeg)+"deg)"
  });
}
</script>
<!-------------------------------------------game view slider--------------------------------------------------->  
<!-------------------------------------------game view slider--------------------------------------------------->  



<!-------------------------------------------tabs--------------------------------------------------->  
<!-------------------------------------------tabs--------------------------------------------------->  
<script>
	function openCity(evt, cityName) {
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.className += " active";
	}
	
	// Get the element with id="defaultOpen" and click on it
	document.getElementById("defaultOpen").click();
</script>
<!-------------------------------------------tabs--------------------------------------------------->  
<!-------------------------------------------tabs--------------------------------------------------->  


    </body>
</html>
<?php /**PATH C:\xampp\htdocs\knight-call\resources\views/contact_us.blade.php ENDPATH**/ ?>