<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
    /* enable user ajax*/
    function enableClick(id)
    {
        var user_id=id;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            status: "active",
            user_id:user_id
        };

        $.ajax({
            type:"POST",
            url: "changeUserStatus",
            data: formData,
            dataType: 'json',
            success: function (data) {
                var userStaus ="Enabled"
                    jQuery("#user-status-" + user_id).text(userStaus);
            },
            error: function (data) {
                console.log(data);
            }
        });
    }
    /* enable user ajax end*/
 /* disable user ajax*/
    function disableClick(id)
    {
        var user_id=id;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            status: "inactive",
            user_id:user_id
        };

        $.ajax({
            type:"POST",
            url: "changeUserStatus",
            data: formData,
            dataType: 'json',
            success: function (data) {
                var userStaus ="Disabled"
                    jQuery("#user-status-" + user_id).text(userStaus);
            },
            error: function (data) {
                console.log(data);
            }
        });
    } /* disable user ajax end*/
</script>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Players</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="UsersList" class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Player Name</th>
                                        <th class="pt-0">Level</th>
                                        <th class="pt-0">Rank</th>
                                        <th class="pt-0">Email</th>
                                        <th class="pt-0">Country</th>
                                        <th class="pt-0">Status</th>
                                        <th class="pt-0">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class="pending"> <?php echo e($item['user_id']); ?></td>
                                            <td> <?php echo e($item['player_name']); ?></td>
                                            <td><?php echo e($item['level']); ?></td>
                                            <td><?php echo e($item['rank']); ?></td>
                                            <td> <?php echo e($item['email']); ?></td>
                                            <td> <?php echo e($item['country_name']); ?></td>
                                            <td id="user-status-<?php echo e($item['user_id']); ?>">
                                                <?php if($item['status'] =="active"): ?>
                                                    Enabled
                                                <?php else: ?>
                                                    Disabled
                                                <?php endif; ?>
                                            </td>
                                            <td><button id="disable-user-<?php echo e($item['user_id']); ?>" onclick="disableClick(<?php echo e($item['user_id']); ?>)"  class="confirm_btn"> <i
                                                        data-feather="user-x"></i>Disable</button>
                                                <button id="enable-user-<?php echo e($item['user_id']); ?>" onclick="enableClick(<?php echo e($item['user_id']); ?>)"  class="confirm_btn verify_btn"><i
                                                        data-feather="user-check"></i>Enable</button>
                                            <a onclick="alert('Are you Sure? All data will be lost !')" href="<?php echo e(route('deleteUser', [$item['user_id']])); ?>" type="button" class="btn btn-danger btn-rounded btn-sm"><i
                                                data-feather="trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#UsersList").dataTable();
    });
</script>
</body>
</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_users.blade.php ENDPATH**/ ?>