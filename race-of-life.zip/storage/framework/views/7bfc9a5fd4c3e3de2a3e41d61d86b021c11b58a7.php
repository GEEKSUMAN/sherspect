<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Robots</h4>
        </div>
        <button type="button" data-toggle="modal"
        data-target="#exampleModalCenterradd"  class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Robot</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="robotsLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="robotsLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th class="pt-0">Rank</th>
                                        <th class="pt-0">Rank ID</th>
                                        <th class="pt-0">Sheild(Min)</th>
                                        <th class="pt-0">Sheild(Max)</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="robotsLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->name); ?></td>
                                            <td> <?php echo e($item->image_url); ?></td>
                                            <td> <?php echo e($item->ranks); ?></td>
                                            <td> <?php echo e($item->rank_id); ?></td>
                                            <td> <?php echo e($item->shield_min_strength); ?></td>
                                            <td> <?php echo e($item->shield_max_strength); ?></td>
                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteRobot" value="<?php echo e($item->id); ?>" class="verify_btn deleteRobot" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Robot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="robot_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="name" type="text" class="border" Value="Class 5" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Image</label>
                    <input id="image_url" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Rank</label>
                    <input id="rank" type="text" disabled class="border" Value="$300" style="padding: 3px 15px;"><br>
                    <input type="hidden" id="rank_id" value="" >
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild(Min)</label>
                    <input id="shield_min_strength" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild(Max)</label>
                    <input id="shield_max_strength" type="text" class="border" Value="$300"
                        style="padding: 3px 15px;"><br>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateRobot" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Robot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input  id="add_name" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Image</label>
                    <input  id="add_image_url" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <div >
                    <label  style="font-weight: 600; width:35% ;  float:left;">Rank</label>
                    <select  class="required"  id="add_rank_id" style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="" selected="selected">Select Rank</option>
                        <?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>">
                                <?php echo e($key->ranks); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild(Min)</label>
                    <input  id="add_shield_min_strength" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Sheild(Max)</label>
                    <input  id="add_shield_max_strength" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addRobot" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#robotsLists").dataTable();
    });
//     $('#add_rank_id').change(function() {
//        alert();
//      });
</script>
<script>
    // Delete Robot
    $("button.deleteRobot").click(function (e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var robot_id=$(this).val();
        var formData= {
            "robot_id":robot_id
        }
        //alert(Robot_id);
        $.ajax({
            type: "POST",
            url: "deleteRobot",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.robotsLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();
        $("#robot_id").val(tableData[0]);
        $("#name").val(tableData[1]);
        $("#image_url").val(tableData[2]);
        $("#rank").val(tableData[3]);
        $("#rank_id").val(tableData[4]);
        var rank_id=tableData[4];
        $("#shield_min_strength").val(tableData[5]);
        $("#shield_max_strength").val(tableData[6]);
        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addRobot').click(function (e) {
        e.preventDefault();
        var $val=0;

//check text fields
    $("input.required").each(function(){
        if (($(this).val())== ""){
              $(this).css('border-color', 'red');
              $val = 1
        }
        else{
            $(this).css('border-color', '');
        }

    });
  //  check select fields
    $("select.required").each(function(){
        if (($(this).val())== ""){
              $(this).css('border-color', 'red');
              $val = 1
        }
        else{
            $(this).css('border-color', '');
        }

    });
    if ($val > 0) {
        alert('Please enter the hightlighted values');
        return false;
    }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "name":$("#add_name").val(),
            "image_url":$("#add_image_url").val(),
            "rank_id":$("#add_rank_id").val(),
            "rank":$( "#add_rank_id option:selected" ).text(),
            "shield_min_strength":$("#add_shield_min_strength").val(),
            "shield_max_strength":$("#add_shield_max_strength").val(),
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addRobot",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateRobot").click(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "robot_id":$("#robot_id").val(),
            "name":$("#name").val(),
            "image_url":$("#image_url").val(),
            "rank_id":$("#rank_id").val(),
            "shield_min_strength":$("#shield_min_strength").val(),
            "shield_max_strength":$("#shield_max_strength").val()
        };
        $.ajax({
            type: "POST",
            url: "updateRobot",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if(data){
                    window.location.reload();
                }
            },
            error: function(data) {
               alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\admin-knightcall\resources\views/all_robots.blade.php ENDPATH**/ ?>