<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Knight Club | ADMIN DASHBOARD</title>
    <!--- DataTable --->
    <link rel="stylesheet" type="text/css"
        href="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css" />
    <!-- core:css -->
    <link rel="stylesheet" href="<?php echo e(asset('/vendors/core/core.css')); ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css" integrity="sha512-f0tzWhCwVFS3WeYaofoLWkTP62ObhewQ1EZn65oSYDZUg1+CyywGKkWzm8BxaJj5HGKI72PnMH9jYyIFz+GH7g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- end plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('/fonts/feather-font/css/iconfont.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/demo_1/style.css')); ?>">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo e(asset('/images/favicon.png')); ?>" />

</head>

<body class="sidebar-dark">
    <div class="main-wrapper">

        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <a href="#" class="sidebar-brand">
                    <img src="<?php echo e(asset('/images/logo.png')); ?>" class="img-fluid" style="width: 65%;" />
                </a>
                <div class="sidebar-toggler not-active">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="sidebar-body">
                <ul class="nav">
                    <li class="nav-item nav-category">Main</li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="box"></i>
                            <span class="link-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllplayers')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="users"></i>
                            <span class="link-title">All Players</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewUserWallets')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="dollar-sign"></i>
                            <span class="link-title">All Players Wallets</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllLevels')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="bar-chart"></i>
                            <span class="link-title">All Defend Levels</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewPVPLeaderboard')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="bar-chart-2"></i>
                            <span class="link-title">PVP Leaderboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllBattalions')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="bar-chart-2"></i>
                            <span class="link-title">Battalions</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllTournaments')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="bar-chart"></i>
                            <span class="link-title">Tournament</span>
                        </a>
                    </li> <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllbattlepasscards')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="bar-chart"></i>
                            <span class="link-title">Battle Pass Cards</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllfighterjets')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="list"></i>
                            <span class="link-title">Fighterjets</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllrobots')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="tv"></i>
                            <span class="link-title">Robots</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAlldrones')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="codesandbox"></i>
                            <span class="link-title">Drones</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllskins')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="user-plus"></i>
                            <span class="link-title">Skins</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllWeapons')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="anchor"></i>
                            <span class="link-title">Weapons</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllwatches')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="compass"></i>
                            <span class="link-title">Watches</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllLoadouts')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="settings"></i>
                            <span class="link-title">Loadouts</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/viewAllMonsters')); ?>" class="nav-link">
                            <i class="link-icon" data-feather="settings"></i>
                            <span class="link-title">Monsters</span>
                        </a>
                    </li>

                </ul>
            </div>
        </nav>

        <!-- partial -->

        <div class="page-wrapper">

            <!-- partial:partials/_navbar.html -->
            <nav class="navbar">
                <a href="#" class="sidebar-toggler">
                    <i data-feather="menu"></i>
                </a>
                <div class="navbar-content">
                    
                    <ul class="navbar-nav">
                        
                        <li class="nav-item dropdown nav-profile">
                            <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo e(asset('/images/faces/face1.jpg')); ?>" alt="profile">
                            </a>
                            <div class="dropdown-menu" aria-labelledby="profileDropdown">
                                <div class="dropdown-header d-flex flex-column align-items-center">
                                    <div class="figure mb-3">
                                        <img src="<?php echo e(asset('/images/faces/face1.jpg')); ?>" alt="">
                                    </div>
                                    <div class="info text-center">
                                        <p class="name font-weight-bold mb-0">Admin</p>
                                        <p class="email text-muted mb-3">admin@email.com</p>
                                    </div>
                                </div>
                                <div class="dropdown-body">
                                    <ul class="profile-nav p-0 pt-3">
                                        
                                        <li class="nav-item">
                                            <a href="<?php echo e(url("/logout")); ?>" class="nav-link">
                                                <i data-feather="log-out"></i>
                                                <span id="logout">Log Out</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- partial -->
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/header.blade.php ENDPATH**/ ?>