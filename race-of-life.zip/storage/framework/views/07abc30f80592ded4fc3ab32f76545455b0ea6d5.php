<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of BattlePass Cards</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Cards</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">
                            <br><br>
                            <table id="battlePassCards" class="table table-hover mb-0">
                                <thead>
                                    <tr class="battlePassCards">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th class="pt-0">Description</th>
                                        <th class="pt-0">Type</th>
                                        <th class="pt-0">Tier</th>
                                        <th class="pt-0">Tier Price</th>
                                        <th class="pt-0">Battel Pass Price</th>
                                        <th class="pt-0">Paid</th>
                                        <th class="pt-0">Item ID</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="battlePassCards">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->name); ?></td>
                                            <td style=" width: 100px; height: 100px; padding: 0;">
                                                <img style="width: 100px;height: 100px;display: block; border-radius: 2px;"
                                                    src="<?php echo e(url('uploads/' . $item->image)); ?>"
                                                    alt="<?php echo e($item->image); ?>" />
                                                <button style="background:#41d1f6" class="verify_btn"
                                                    data-toggle="modal" data-target="#modalImg"><i data-feather="upload"
                                                        style="width: 30%;"></i>Change</button>
                                            </td>
                                            <td> <?php echo e($item->description); ?></td>
                                            <td> <?php echo e($item->type); ?></td>
                                            <td> <?php echo e($item->tier); ?></td>
                                            <td> <?php echo e($item->tier_price); ?></td>
                                            <td> <?php echo e($item->battel_pass_price); ?></td>
                                            <td> <?php echo e($item->is_paid); ?></td>
                                            <td> <?php echo e($item->item_id); ?></td>

                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteBattlePassCard" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deleteBattlePassCard"
                                                    style="background: #e32929;"><i data-feather="trash-2"
                                                        style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit BattlePass Card</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="battlePassCard_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="card_name" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Description</label>
                    <input id="description" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Type</label>
                    <input id="type" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Tier</label>
                    <input id="tier" type="text" class="border" Value="" style="padding: 3px 15px;"><br><label
                        style="margin-right: 23px;font-weight: 600;width: 30%;">Tier Price</label>
                    <input id="tier_price" type="text" class="border" Value="" style="padding: 3px 15px;"><br><label
                        style="margin-right: 23px;font-weight: 600;width: 30%;">Battle Pass Price</label>
                    <input id="battel_pass_price" type="text" class="border" Value="" style="padding: 3px 15px;"><br><label
                        style="margin-right: 23px;font-weight: 600;width: 30%;">Paid</label>
                    <input id="is_paid" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br><label
                        style="margin-right: 23px;font-weight: 600;width: 30%;">Item Id</label>
                    <input id="item_id" type="text" class="border" Value="" style="padding: 3px 15px;"><br>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateBattlePassCard" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add BattlePass Card</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_card_name" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>

                    <div>
                        <label style="font-weight: 600; width:35% ;  float:left;">Description</label>
                        <input id="add_description" type="text" class="required" Value=""
                            style="padding: 3px 15px;"><br>
                    </div>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Type</label>
                    <input id="add_type" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Tier</label>
                    <input id="add_tier" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Tier Price</label>
                    <input id="add_tier_price" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Battle Pass Price</label>
                    <input id="add_battel_pass_price" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Paid</label>
                    <input id="add_is_paid" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Item ID</label>
                    <input id="add_item_id" type="text" class="required" Value="" style="padding: 3px 15px;"><br>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addbattlePassCard" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal img -->
<div class="modal fade" id="modalImg" tabindex="-1" role="dialog" aria-labelledby="modalImgtitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalImgtitle">Change Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="file" accept="image/x-png,image/gif,image/jpeg" id="file">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="img_upload" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal img -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#battlePassCards").dataTable();
    });
    //     $('#add_rank_id').change(function() {
    //        alert();
    //      });
</script>
<script>
    // Delete BattlePass Card
    $("button.deleteBattlePassCard").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var battlePassCard_id = $(this).val();
        var formData = {
            "battlePassCard_id": battlePassCard_id
        }
        //alert(battlePassCard_id);
        $.ajax({
            type: "POST",
            url: "deletebattlePassCard",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.battlePassCards").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();

        $("#battlePassCard_id").val(tableData[0]);
        $("#card_name").val(tableData[1]);
        var description = jQuery.trim(tableData[3]);
        $("#description").val(description);
        $("#type").val(tableData[4]);
        $("#tier").val(tableData[5]);
        $("#tier_price").val(tableData[6]);
        $("#battel_pass_price").val(tableData[7]);
        $("#is_paid").val(tableData[8]);
        $("#item_id").val(tableData[9]);

        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addbattlePassCard').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        //  check select fields
        $("select.description").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "card_name": $("#add_card_name").val(),
            "type": $("#add_type").val(),
            "description": $("#add_description").val(),
            "tier_price": $("#add_tier_price").val(),
            "tier": $("#add_tier").val(),
            "battel_pass_price": $("#add_battel_pass_price").val(),
            "is_paid": $("#add_is_paid").val(),
            "item_id": $("#add_item_id").val(),

        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addbattlePassCard",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateBattlePassCard").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "battlePassCard_id": $("#battlePassCard_id").val(),
            "card_name": $("#card_name").val(),
            "description": $("#description").val(),
            "type": $("#type").val(),
            "tier": $("#tier").val(),
            "tier_price": $("#tier").val(),
            "battel_pass_price": $("#battel_pass_price").val(),
            "is_paid": $("#is_paid").val(),
            "item_id": $("#item_id").val(),
        };
        $.ajax({
            type: "POST",
            url: "updatebattlePassCard",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>
<script>
    $(document).ready(function() {
        $("#img_upload").click(function() {
            var fd = new FormData();
            var files = $('#file')[0].files;
            // Check file selected or not
            if (files.length > 0) {
                fd.append('file', files[0]);
                fd.append('battlePassCard_id', $("#battlePassCard_id").val());
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: 'uploadBattlePassFile',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.res != 0) {
                            window.location.reload();
                        } else {
                            alert('file not uploaded');
                        }
                    },
                });
            } else {
                alert("Please select a file.");
            }
        });
    });
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_battlePassCards.blade.php ENDPATH**/ ?>