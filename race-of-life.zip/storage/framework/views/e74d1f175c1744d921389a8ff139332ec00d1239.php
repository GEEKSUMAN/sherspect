<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-content">

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3 mb-md-0">List of Watches</h4>
        </div>
        <button type="button" data-toggle="modal" data-target="#exampleModalCenterradd"
            class="btn btn-primary pull-right"><i data-feather="plus"></i>Add Watch</button>
    </div>
    <div class="row">
        <div class="col-lg-12 col-xl-12 grid-margin grid-margin-xl-0 stretch-card mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column">
                        <div class="table-responsive">

                            <br><br>
                            <table id="WatchesLists" class="table table-hover mb-0">
                                <thead>
                                    <tr class="WatchesLists">
                                        <th class="pt-0">Id</th>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">Image</th>
                                        <th class="pt-0">Paid</th>
                                        <th class="pt-0">Price(JCU)</th>
                                        <th class="pt-0">Looting Capacity</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="WatchesLists">
                                            <td class="pending"> <?php echo e($item->id); ?></td>
                                            <td> <?php echo e($item->watch_name); ?></td>
                                            <td style=" width: 100px; height: 100px; padding: 0;">
                                                <img style="width: 100px;height: 100px;display: block; border-radius: 2px;"
                                                    src="<?php echo e(url('uploads/' . $item->watch_image)); ?>"
                                                    alt="<?php echo e($item->watch_image); ?>" />
                                                <button style="background:#41d1f6" class="verify_btn"
                                                    data-toggle="modal" data-target="#modalImg"><i data-feather="upload"
                                                        style="width: 30%;"></i>Change</button>
                                            </td>
                                            <td> <?php echo e($item->status); ?></td>
                                            <td> <?php echo e($item->gcu_value); ?></td>
                                            <td> <?php echo e($item->Looting_capacity); ?></td>

                                            <td><button class="verify_btn" data-toggle="modal"
                                                    data-target="#exampleModalCenterr"><i data-feather="edit"
                                                        style="width: 30%;"></i> Edit</button>
                                                <button id="deleteWatch" value="<?php echo e($item->id); ?>"
                                                    class="verify_btn deleteWatch" style="background: #e32929;"><i
                                                        data-feather="trash-2" style="width: 30%;"></i> Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- row -->

        </div>

    </div>
</div>
<!-- Modal update -->
<div class="modal fade" id="exampleModalCenterr" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Watch</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">ID</label>
                    <input id="watch_id" type="text" class="border" disabled Value="Class 5"
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="watch_name" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="font-weight: 600; width:35% ;  float:left;">Paid Status</label>
                    <select class="required" id="status"
                        style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                        <option value="">Select Paid Status</option>
                        <option value="1">
                            Yes
                        </option>
                        <option value="0">
                            No
                        </option>

                    </select>

                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Price(JCU)</label>
                    <input id="gcu_value" type="text" class="border" Value="" style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Looting Capacity</label>
                    <input id="Looting_capacity" type="text" class="border" Value=""
                        style="padding: 3px 15px;"><br>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="updateWatch" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal add -->
<div class="modal fade" id="exampleModalCenterradd" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Watch</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="dropify-wrapper" style="padding: 20px;">
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Name</label>
                    <input id="add_watch_name" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>

                    <div>
                        <label style="font-weight: 600; width:35% ;  float:left;">Paid Status</label>
                        <select class="status" id="add_status"
                            style="width:65%;float:right ;margin-bottom: 4px; padding: 3px 15px;" name="product_id">
                            <option value="" selected>Select Paid Status</option>
                            <option value="1">
                                Yes
                            </option>
                            <option value="0">
                                No
                            </option>

                        </select>
                    </div>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Price(JCU)</label>
                    <input id="add_gcu_value" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                    <label style="margin-right: 23px;font-weight: 600;width: 30%;">Looting Capacity</label>
                    <input id="add_Looting_capacity" type="text" class="required" Value=""
                        style="padding: 3px 15px;"><br>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="addWatch" type="button" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal img -->
<div class="modal fade" id="modalImg" tabindex="-1" role="dialog" aria-labelledby="modalImgtitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalImgtitle">Change Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="file" accept="image/x-png,image/gif,image/jpeg" id="file">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="img_upload" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal img -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(function() {
        var table = $("#WatchesLists").dataTable();
    });
    //     $('#add_rank_id').change(function() {
    //        alert();
    //      });
</script>
<script>
    // Delete Watch
    $("button.deleteWatch").click(function(e) {
        e.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var watch_id = $(this).val();
        var formData = {
            "watch_id": watch_id
        }
        //alert(watch_id);
        $.ajax({
            type: "POST",
            url: "deleteWatch",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('Error Occured')

            }
        });
    });
</script>
<script>
    $("tr.WatchesLists").click(function() {
        var tableData = $(this).children("td").map(function() {
            return $(this).text();
        }).get();

        $("#watch_id").val(tableData[0]);
        $("#watch_name").val(tableData[1]);
        var status=  jQuery.trim(tableData[3]);
        $("#status").val(status);
        $("#gcu_value").val(tableData[4]);
        $("#Looting_capacity").val(tableData[5]);

        // alert(tableData);
        // console.log(tableData);
    });
</script>
<script>
    $('#addWatch').click(function(e) {
        e.preventDefault();
        var $val = 0;

        //check text fields
        $("input.required").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        //  check select fields
        $("select.status").each(function() {
            if (($(this).val()) == "") {
                $(this).css('border-color', 'red');
                $val = 1
            } else {
                $(this).css('border-color', '');
            }

        });
        if ($val > 0) {
            alert('Please enter the hightlighted values');
            return false;
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData = {
            "watch_name": $("#add_watch_name").val(),

            "gcu_value": $("#add_gcu_value").val(),
            "status": $("#add_status option:selected").val(),
            "Looting_capacity": $("#add_Looting_capacity").val()
        };
        //alert(formData);
        $.ajax({
            type: "POST",
            url: "addWatch",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
</script>
<script>
    $("#updateWatch").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        var formData = {
            "watch_id": $("#watch_id").val(),
            "watch_name": $("#watch_name").val(),
            "status": $("#status option:selected").val(),
            "gcu_value": $("#gcu_value").val(),
            "Looting_capacity": $("#Looting_capacity").val()
        };
        $.ajax({
            type: "POST",
            url: "updateWatch",
            data: formData,
            dataType: 'json',
            success: function(data) {
                if (data) {
                    window.location.reload();
                }
            },
            error: function(data) {
                alert('check inputs')

            }
        });
    });
    // /* enable update ajax end*/
</script>
<script>
    $(document).ready(function() {
        $("#img_upload").click(function() {
            var fd = new FormData();
            var files = $('#file')[0].files;
            // Check file selected or not
            if (files.length > 0) {
                fd.append('file', files[0]);
                fd.append('watch_id',$("#watch_id").val());
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: 'uploadWatch',
                    type: 'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.res != 0) {
                            window.location.reload();
                        } else {
                            alert('file not uploaded');
                        }
                    },
                });
            } else {
                alert("Please select a file.");
            }
        });
    });
</script>

</body>

</html>
<?php /**PATH /home/lolonimir/public_html/admin.knightcall.com/resources/views/all_watches.blade.php ENDPATH**/ ?>